# Co jest w paczce i jak to wrzucić

Paczka rozpakowuje się **prosto do katalogu głównego repo**
`luckybause/peltier-controlv2`, obok istniejącego `peltier_control.py`:

```
peltier-controlv2/
├─ peltier_control.py        ← stary build Tkinter, NIETKNIĘTY
├─ lachi_app.py              ← NOWE: aplikacja PyQt6 (uruchamiasz to)
├─ lachi/                    ← NOWE: warstwa interfejsu
│  ├─ __init__.py
│  ├─ core.py                stałe, protokół CSV, okienka systemowe
│  ├─ theme.py               paleta Apple (jasna + ciemna) i arkusz stylów
│  ├─ icons.py               30 ikon rysowanych, nie licencjonowanych
│  ├─ brand.py               logotyp LACHI i emblemat jako geometria
│  ├─ chart.py               wykresy matplotlib + zoom myszą
│  ├─ widgets.py             komponenty Cupertino, których Qt nie ma
│  ├─ dialogs.py             wszystkie arkusze (diagnostyka, presety, kalibracja…)
│  └─ assets/README.txt      opcjonalne fonty — może zostać puste
└─ requirements.txt          ← NOWE (dopisane PyQt6)
```

## Uruchomienie lokalnie

```bash
pip install -r requirements.txt
python lachi_app.py
```

Na Linuksie Qt potrzebuje jeszcze `libxcb-cursor0`. Na Windowsie i macOS nic
dodatkowego.

## Wrzucenie na GitHuba

W katalogu ze sklonowanym repo:

```bash
git checkout -b feature/pyqt6-ios-ui
git add lachi_app.py lachi/ requirements.txt
git commit -m "Add PyQt6 interface (LACHI) alongside the Tkinter build"
git push -u origin feature/pyqt6-ios-ui
```

Potem na GitHubie kliknij **Compare & pull request**. Albo, jeśli wolisz bez
gałęzi i bez PR-a — to samo na `main`:

```bash
git add lachi_app.py lachi/ requirements.txt
git commit -m "Add PyQt6 interface (LACHI) alongside the Tkinter build"
git push
```

## Czy to coś zepsuje?

**Nie.**

- `peltier_control.py` nie jest ruszony — stara aplikacja działa dalej.
- Workflow `.github/workflows/main.yml` buduje EXE z `peltier_control.py`
  i instaluje zależności jawnie (`pip install pyserial matplotlib pyinstaller`),
  a nie z `requirements.txt` — więc dopisanie tam PyQt6 nie zmienia CI.
- `build.bat` buduje z `app\peltier_control.py` — też bez zmian.

## Dwie rzeczy do uporządkowania (kiedyś, nie teraz)

W repo leżą **trzy różne** kopie starej aplikacji, które się rozjechały:
`peltier_control.py` (ta z korzenia, najnowsza), `app/peltier_control.py`
(starsza) i `PeltierControl` (jeszcze starszy skrypt „BRUTALIST"). CI buduje
z pierwszej, `build.bat` z drugiej — czyli EXE z Actions i EXE z bata to nie
jest ten sam program. Warto kiedyś zostawić jedną.

## Jeśli chcesz, żeby EXE budował się z nowej aplikacji

W `.github/workflows/main.yml` zmień linię z zależnościami i linię PyInstallera:

```yaml
- run: pip install pyserial matplotlib PyQt6 pyinstaller
- run: >
    pyinstaller --onefile --windowed --name LACHI
    --collect-all matplotlib --collect-all PyQt6
    --add-data "lachi/assets;lachi/assets"
    lachi_app.py
```

Ale to osobna decyzja — dopóki jej nie podejmiesz, CI produkuje dokładnie to
co dotąd.
