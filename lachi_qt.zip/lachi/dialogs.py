#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - the secondary windows, in the iOS idiom.

iOS has two shapes for a window that is not the main screen: a SHEET (slides
up, carries its own Cancel/Done, used for a task you finish and dismiss) and a
full screen pushed onto a stack. Qt has neither, so each of these is a QDialog
wearing the same grouped-list vocabulary as the main window - header row with
the title and a Done button, grouped cards below.
"""
from __future__ import annotations

import threading
import time
from datetime import datetime

from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import (QDialog, QGridLayout, QHBoxLayout, QLabel,
                             QLineEdit, QListWidget, QScrollArea, QTextEdit,
                             QVBoxLayout, QWidget)

from . import core, widgets as W
from .theme import PAD, Theme


# ════════════════════════════════════════════════════════════════════════
#  BASE
# ════════════════════════════════════════════════════════════════════════
class Sheet(QDialog):
    """A dialog shaped like an iOS sheet: title bar with actions, then a
    scrolling column of grouped cards."""

    def __init__(self, parent, theme: Theme, title: str, subtitle: str = "",
                 width: int = 560, height: int = 620):
        super().__init__(parent)
        self.th = theme
        self.setWindowTitle(title)
        self.setObjectName('page')
        self.resize(theme.px(width), theme.px(height))
        self.setStyleSheet(theme.qss())

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        bar = QWidget()
        bl = QHBoxLayout(bar)
        bl.setContentsMargins(theme.px(PAD), theme.px(12), theme.px(PAD),
                              theme.px(8))
        col = QVBoxLayout()
        col.setSpacing(0)
        t = QLabel(title)
        t.setStyleSheet("QLabel { font-size: %dpt; font-weight: 700; }"
                        % theme.pt('title2'))
        col.addWidget(t)
        if subtitle:
            s = QLabel(subtitle)
            s.setWordWrap(True)
            s.setStyleSheet(f"color: {theme['label2']}; "
                            f"font-size: {theme.pt('footnote')}pt;")
            col.addWidget(s)
        bl.addLayout(col)
        bl.addStretch(1)
        self.actions = QHBoxLayout()
        self.actions.setSpacing(theme.px(6))
        bl.addLayout(self.actions)
        root.addWidget(bar)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        body = QWidget()
        body.setObjectName('bg')
        self.col = QVBoxLayout(body)
        self.col.setContentsMargins(theme.px(PAD), theme.px(4),
                                    theme.px(PAD), theme.px(16))
        self.col.setSpacing(theme.px(16))
        self.scroll.setWidget(body)
        root.addWidget(self.scroll, 1)

        self.footer = QHBoxLayout()
        self.footer.setContentsMargins(theme.px(PAD), 0, theme.px(PAD),
                                       theme.px(PAD))
        self.footer.setSpacing(theme.px(10))
        root.addLayout(self.footer)

    def add(self, w):
        self.col.addWidget(w)
        return w

    def done_button(self, text="Done"):
        b = W.button(self.th, text, 'plain', on_click=self.accept)
        self.actions.addWidget(b)
        return b

    @staticmethod
    def clear_group(group: 'W.Group'):
        """Empty a Group so it can be rebuilt. A handful of rows, and it keeps
        the separator bookkeeping in one place."""
        while group.card.box.count():
            it = group.card.box.takeAt(0)
            if it.widget():
                it.widget().deleteLater()
        group._rows = 0


# ════════════════════════════════════════════════════════════════════════
#  SAVE A RUN
# ════════════════════════════════════════════════════════════════════════
class SaveCycleDialog(Sheet):
    """Asked for after every manual run. Closing the window SAVES - discarding
    a measurement has to be a deliberate act, not the consequence of an
    impatient click on the X."""

    def __init__(self, parent, theme, app, tmp_path):
        rows = getattr(app, 'cyc_rows', 0)
        super().__init__(parent, theme, "Save run",
                         f"{rows} samples recorded", 460, 320)
        self.app = app
        self.tmp_path = tmp_path
        self._done = False

        g = W.Group(theme, "Name")
        self.entry = QLineEdit(datetime.now().strftime("test_%H%M"))
        self.entry.returnPressed.connect(self.save)
        g.add_widget(self._pad(self.entry), sep=False)
        self.add(g)
        self.col.addStretch(1)

        save = W.button(theme, "Save to archive", 'filled', 'check', self.save)
        save.setMinimumHeight(theme.px(46))
        disc = W.button(theme, "Discard", 'destructive', 'trash', self.discard)
        disc.setMinimumHeight(theme.px(46))
        self.footer.addWidget(save, 2)
        self.footer.addWidget(disc, 1)

        self.entry.setFocus()
        self.entry.selectAll()

    def _pad(self, w):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(self.th.px(12), self.th.px(10),
                               self.th.px(12), self.th.px(12))
        lay.addWidget(w)
        return box

    def save(self):
        if self._done:
            return
        self._done = True
        name = self.entry.text().strip() or datetime.now().strftime("cykl_%H%M")
        self.app.save_cycle_as(self.tmp_path, name)
        self.accept()

    def discard(self):
        if core.ask(self, "Discard this run?",
                    "The data will be permanently deleted."):
            self._done = True
            self.app.discard_cycle(self.tmp_path)
            self.reject()

    def closeEvent(self, e):
        # Closing the window saves - see the class docstring.
        if not self._done:
            self.save()
        e.accept()


# ════════════════════════════════════════════════════════════════════════
#  PRESETS
# ════════════════════════════════════════════════════════════════════════
class PresetDialog(Sheet):
    def __init__(self, parent, theme, app):
        super().__init__(parent, theme, "Presets",
                         "Complete settings - setpoint, ramps, fans", 520, 560)
        self.app = app
        self.done_button()

        g = W.Group(theme, "Save current settings as")
        self.name = QLineEdit("My preset")
        self.name.returnPressed.connect(self.save_preset)
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(theme.px(12), theme.px(10), theme.px(12),
                              theme.px(12))
        rl.setSpacing(theme.px(8))
        rl.addWidget(self.name, 1)
        rl.addWidget(W.button(theme, "Save", 'filled', '', self.save_preset))
        g.add_widget(row, sep=False)
        self.add(g)

        self.list_group = W.Group(theme, "Saved presets")
        self.add(self.list_group)
        self.col.addStretch(1)
        self.refresh()

    def refresh(self):
        self.clear_group(self.list_group)
        presets = self.app._load_presets()
        if not presets:
            self.list_group.add_row("No presets yet",
                                    sub="Save the current settings above")
            return
        for name, s in presets.items():
            right = QWidget()
            rl = QHBoxLayout(right)
            rl.setContentsMargins(0, 0, 0, 0)
            rl.setSpacing(self.th.px(4))
            rl.addWidget(W.button(self.th, "Load", 'plain', '',
                                  lambda _=False, n=name: self.load(n)))
            rl.addWidget(W.icon_button(self.th, 'trash', "Delete",
                                       lambda _=False, n=name: self.delete(n),
                                       color='red', size=18))
            sub = (f"SP {s.get('sp', '?')} °C  ·  up {s.get('ru', '?')} / "
                   f"down {s.get('rd', '?')} °C/min  ·  fan {s.get('fan', '?')} %")
            self.list_group.add_row(name, right, sub=sub)

    def save_preset(self):
        name = self.name.text().strip()
        if not name:
            core.info(self, "Name required", "Enter a preset name.")
            return
        presets = self.app._load_presets()
        if name in presets and not core.ask(
                self, "Overwrite?", f"Preset '{name}' already exists."):
            return
        presets[name] = self.app._gather_settings()
        if self.app._save_presets(presets):
            self.refresh()

    def load(self, name):
        presets = self.app._load_presets()
        if name in presets:
            self.app.apply_preset(presets[name])
            self.accept()

    def delete(self, name):
        if core.ask(self, "Delete preset?", f"'{name}' will be removed."):
            presets = self.app._load_presets()
            presets.pop(name, None)
            self.app._save_presets(presets)
            self.refresh()


# ════════════════════════════════════════════════════════════════════════
#  MULTI-STEP PROFILES
# ════════════════════════════════════════════════════════════════════════
class ProfileDialog(Sheet):
    def __init__(self, parent, theme, app):
        super().__init__(parent, theme, "Profiles",
                         "A chain of temperature / ramp / dwell steps sent "
                         "straight to the board", 540, 560)
        self.app = app
        self.done_button()

        g = W.Group(theme, "Add step")
        row = QWidget()
        rl = QHBoxLayout(row)
        rl.setContentsMargins(theme.px(12), theme.px(10), theme.px(12),
                              theme.px(12))
        rl.setSpacing(theme.px(8))
        self.e_temp = QLineEdit("40")
        self.e_ramp = QLineEdit("2.0")
        self.e_time = QLineEdit("10")
        for e, unit in ((self.e_temp, "°C"), (self.e_ramp, "°C/min"),
                        (self.e_time, "min")):
            box = QVBoxLayout()
            box.setSpacing(2)
            cap = QLabel(unit)
            cap.setStyleSheet(f"color: {theme['label3']}; "
                              f"font-size: {theme.pt('caption2')}pt;")
            box.addWidget(e)
            box.addWidget(cap)
            rl.addLayout(box, 1)
        rl.addWidget(W.button(theme, "Add", 'tinted', 'plus', self.add_step))
        g.add_widget(row, sep=False)
        self.add(g)

        self.steps = W.Group(theme, "Steps")
        self.add(self.steps)
        self.col.addStretch(1)

        run = W.button(theme, "Run profile", 'filled', 'play', self.run_profile)
        run.setMinimumHeight(theme.px(46))
        self.footer.addWidget(run)
        self.refresh()

    def refresh(self):
        self.clear_group(self.steps)
        if not self.app.profile_steps:
            self.steps.add_row("No steps", sub="Add one above")
            return
        for i, s in enumerate(self.app.profile_steps):
            btn = W.icon_button(self.th, 'trash', "Remove",
                                lambda _=False, idx=i: self.delete(idx),
                                color='red', size=18)
            self.steps.add_row(f"{i + 1}.  {s['temp']:.0f} °C",
                               btn,
                               sub=f"{s['ramp']:.1f} °C/min  ·  hold "
                                   f"{s['time']:.0f} min")

    def add_step(self):
        try:
            temp = float(self.e_temp.text().replace(',', '.'))
            ramp = float(self.e_ramp.text().replace(',', '.'))
            tmin = float(self.e_time.text().replace(',', '.'))
        except ValueError:
            core.error(self, "Invalid value", "Enter numbers.")
            return
        self.app.profile_steps.append({'temp': temp, 'ramp': ramp, 'time': tmin})
        self.refresh()

    def delete(self, idx):
        if 0 <= idx < len(self.app.profile_steps):
            self.app.profile_steps.pop(idx)
            self.refresh()

    def run_profile(self):
        if not self.app.connected:
            core.warn(self, "Not connected", "Connect to the device first.")
            return
        if not self.app.profile_steps:
            core.info(self, "Empty profile", "Add at least one step.")
            return
        if not core.ask(self, "Run profile?",
                        f"{len(self.app.profile_steps)} steps will run one "
                        "after another."):
            return
        threading.Thread(target=self._run, daemon=True).start()
        self.accept()

    def _run(self):
        for i, s in enumerate(self.app.profile_steps):
            self.app.send(f"SP:{s['temp']:.1f}")
            self.app.send(f"RU:{s['ramp']:.1f}")
            self.app.send(f"RD:{s['ramp']:.1f}")
            if i == 0:
                time.sleep(0.1)
                self.app.send("START")
            time.sleep(max(1, s['time'] * 60))
        self.app.send("STOP")


# ════════════════════════════════════════════════════════════════════════
#  DIAGNOSTICS
# ════════════════════════════════════════════════════════════════════════
class DiagnosticsDialog(Sheet):
    """Everything the firmware sends over Serial, not only the CSV telemetry:
    ERR codes decoded into readable text, calibration warnings, and every other
    line the app would otherwise drop silently. Worth having, because a Serial
    Monitor cannot run in parallel with the app on the same COM port."""

    def __init__(self, parent, theme, app):
        super().__init__(parent, theme, "Diagnostics",
                         "Events and errors reported by the firmware", 660, 580)
        self.app = app
        self.done_button("Close")

        self.alarms = W.Group(theme, "Active alarms")
        self.add(self.alarms)

        card = W.Card(theme, pad=0)
        self.text = QTextEdit()
        self.text.setReadOnly(True)
        self.text.setStyleSheet(
            f"background: transparent; border: none; "
            f"font-family: monospace; font-size: {theme.pt('footnote')}pt;")
        lay = QVBoxLayout()
        lay.setContentsMargins(theme.px(10), theme.px(8), theme.px(10),
                               theme.px(8))
        lay.addWidget(self.text)
        card.box.addLayout(lay)
        card.setMinimumHeight(theme.px(260))
        self.add(card)

        self.footer.addWidget(W.button(theme, "Save to file", 'tinted', 'export',
                                       self.export_log))
        self.footer.addWidget(W.button(theme, "Clear", 'destructive', '',
                                       self.clear_log))
        self.footer.addStretch(1)

        self.refresh_active()
        self.reload_log()

    # -- alarms ---------------------------------------------------------
    def refresh_active(self):
        self.clear_group(self.alarms)
        if not self.app.err_active:
            r = self.alarms.add_row("No active alarms")
            r.title.setStyleSheet(f"color: {self.th['green']};")
            return
        for code, text in self.app.err_active.items():
            r = self.alarms.add_row(f"[{code}]", sub=text)
            r.title.setStyleSheet(f"color: {self.th['red']};")
            if r.sub:
                r.sub.setWordWrap(True)

    # -- log ------------------------------------------------------------
    def reload_log(self):
        self.text.clear()
        for e in self.app.diag_log:
            self._insert(e)

    def append_entry(self, entry):
        self._insert(entry)
        self.text.verticalScrollBar().setValue(
            self.text.verticalScrollBar().maximum())
        self.refresh_active()

    def _insert(self, entry):
        ts, level, text = entry
        col = {'ERR': self.th['red'], 'WARN': self.th['orange']}.get(
            level, self.th.solid('label2', 'card'))
        tstr = datetime.fromtimestamp(ts).strftime('%H:%M:%S')
        self.text.append(
            f'<span style="color:{self.th["label3"]}">[{tstr}]</span> '
            f'<span style="color:{col}"><b>{level}</b> {text}</span>')

    def clear_log(self):
        self.app.diag_log = []
        self.reload_log()

    def export_log(self):
        try:
            fn = self.app.log_dir / (
                f"diagnostics_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt")
            with open(fn, 'w', encoding='utf-8') as f:
                for ts, level, text in self.app.diag_log:
                    tstr = datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
                    f.write(f"[{tstr}] {level:<4} {text}\n")
            core.info(self, "Saved", str(fn))
        except Exception as e:
            core.error(self, "Save error", str(e))

    def closeEvent(self, e):
        self.app.diag_win = None
        e.accept()

    def reject(self):
        self.app.diag_win = None
        super().reject()

    def accept(self):
        self.app.diag_win = None
        super().accept()


# ════════════════════════════════════════════════════════════════════════
#  RUN STATISTICS
# ════════════════════════════════════════════════════════════════════════
class StatsDialog(Sheet):
    def __init__(self, parent, theme, name, st):
        super().__init__(parent, theme, "Run statistics", name, 480, 580)
        self.done_button()

        def settle():
            return (f"{st['settle_time']:.0f} s"
                    if st['settle_time'] is not None else "not reached")

        g1 = W.Group(theme, "Shape of the run")
        g1.add_row("Temperature range",
                   W.value_label(theme, f"{st['tmin']:.1f} – {st['tmax']:.1f} °C",
                                 'blue'))
        g1.add_row("Target", W.value_label(theme, f"{st['target']:.1f} °C",
                                           'orange'))
        g1.add_row("Duration", W.value_label(
            theme, core.fmt_hms(st['duration'])))
        g1.add_row("Average rise rate",
                   W.value_label(theme, f"{st['avg_rise']:.2f} °C/min", 'teal'))
        self.add(g1)

        g2 = W.Group(theme, "Control quality")
        g2.add_row("Overshoot", W.value_label(
            theme, f"{st['overshoot']:.2f} °C",
            'red' if st['overshoot'] > 1 else 'green'))
        g2.add_row("Settling time (±1 °C)", W.value_label(theme, settle()))
        g2.add_row("Steady-state error",
                   W.value_label(theme, f"{st['steady_error']:.3f} °C"))
        g2.add_row("Max deviation from ramp",
                   W.value_label(theme, f"{st['max_dev']:.2f} °C"))
        self.add(g2)

        noise = st['noise_std']
        interp = ("Excellent - low noise" if noise < 0.2 else
                  "Moderate noise" if noise < 0.5 else
                  "High noise - check shielding and grounding")
        g3 = W.Group(theme, "Measurement quality", footer=interp)
        g3.add_row("Noise σ", W.value_label(
            theme, f"±{noise:.3f} °C",
            'green' if noise < 0.2 else 'yellow' if noise < 0.5 else 'red'))
        self.add(g3)
        self.col.addStretch(1)


# ════════════════════════════════════════════════════════════════════════
#  CALIBRATION TABLE
# ════════════════════════════════════════════════════════════════════════
class CalTableDialog(Sheet):
    """The temp x ramp grid of calibrated gains, exactly as the firmware holds
    it. PT/PR must stay IDENTICAL to PT[]/PR[] in the .ino, or idx = ri*len(PR)
    + ci points at the wrong cells."""
    PT = [20, 30, 40, 50, 60, 70, 80, 90, 100]
    PR = [5, 10, 20, 30, 40, 50, 60, 70, 80]

    def __init__(self, parent, theme, profiles, is_base):
        n_valid = sum(1 for p in profiles if p['valid'])
        n_fb = sum(1 for p in profiles if p['valid'] and is_base(p))
        sub = (f"{n_valid} of {len(profiles)} grid points calibrated. "
               "Empty cells fall back to the base gains 10 / 0.3 / 0.8.")
        if n_fb:
            sub += (f"  {n_fb} of them are EXACTLY the base values - almost "
                    "certainly a relay test that failed and fell back, not a "
                    "real measurement (shown in red).")
        super().__init__(parent, theme, "Calibration table", sub, 880, 620)
        self.done_button()

        pmap = {p['idx']: p for p in profiles}
        card = W.Card(theme, pad=0)
        grid = QWidget()
        gl = QGridLayout(grid)
        gl.setContentsMargins(theme.px(10), theme.px(10), theme.px(10),
                              theme.px(10))
        gl.setSpacing(theme.px(2))

        def cell(text, colour, bold=False):
            lb = QLabel(text)
            lb.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lb.setStyleSheet("QLabel { color: %s; font-size: %dpt;%s }"
                             % (colour, theme.pt('caption2'),
                                " font-weight: 600;" if bold else ""))
            return lb

        gl.addWidget(cell("temp \\ ramp", theme['label2'], True), 0, 0)
        for ci, r in enumerate(self.PR):
            gl.addWidget(cell(f"{r}", theme['teal'], True), 0, ci + 1)
        for ri, t in enumerate(self.PT):
            gl.addWidget(cell(f"{t} °C", theme['orange'], True), ri + 1, 0)
            for ci, _ in enumerate(self.PR):
                p = pmap.get(ri * len(self.PR) + ci)
                if p and p['valid']:
                    txt = f"{p['KpH']:.1f}/{p['KiH']:.2f}/{p['KdH']:.2f}"
                    col = theme['red'] if is_base(p) else theme['label']
                else:
                    txt, col = "—", theme['label3']
                gl.addWidget(cell(txt, col), ri + 1, ci + 1)

        lay = QVBoxLayout()
        lay.addWidget(grid)
        card.box.addLayout(lay)
        self.add(card)
        self.col.addStretch(1)


# ════════════════════════════════════════════════════════════════════════
#  AUTO-CALIBRATION RANGE
# ════════════════════════════════════════════════════════════════════════
class CalRangeDialog(Sheet):
    RECOMMENDED = [5, 10, 20, 30, 40, 50, 60, 70, 80]

    def __init__(self, parent, theme, app):
        super().__init__(parent, theme, "Auto-calibration",
                         "Pick the temperature range and the ramps to measure",
                         560, 640)
        self.app = app
        self.custom_ramps = list(self.RECOMMENDED)
        self.rate_step = 5

        g = W.Group(theme, "Temperature range",
                    footer="Step is fixed at 10 °C by the firmware.")
        self.sl_tmin, _ = self._slider(g, "From", -10, 100,
                                       getattr(app, 'dev_cal_min', 50.0), "°C")
        self.sl_tmax, _ = self._slider(g, "To", 0, 115,
                                       getattr(app, 'dev_cal_max', 100.0), "°C")
        self.add(g)

        g2 = W.Group(theme, "Ramps")
        self.sl_max, _ = self._slider(g2, "Max rate", 5, 80, 40, "°C/min")
        self.seg = W.Segmented(theme, ["5", "10", "20", "40"], 0)
        self.seg.changed.connect(self._set_step)
        g2.add_row("Uniform step", self.seg)
        self.btn_rec = W.button(theme, "Recommended list", 'tinted', 'check',
                                self._use_recommended)
        g2.add_row("5 / 10 / 20 … 80", self.btn_rec)
        self.add(g2)

        self.preview = W.Group(theme, "Plan")
        self.row_ramps = self.preview.add_row("Ramps", W.value_label(theme, ""))
        self.row_est = self.preview.add_row("Estimate", W.value_label(theme, ""))
        self.add(self.preview)
        self.col.addStretch(1)

        start = W.button(theme, "Start calibration", 'filled', 'play', self.start)
        start.setMinimumHeight(theme.px(46))
        cancel = W.button(theme, "Cancel", 'plain', '', self.reject)
        cancel.setMinimumHeight(theme.px(46))
        self.footer.addWidget(start, 2)
        self.footer.addWidget(cancel, 1)
        self._update_estimate()

    def _slider(self, group, label, lo, hi, init, unit):
        sl = W.Slider(lo, hi, 1.0)
        sl.setValueF(init, silent=True)
        sl.setFixedWidth(self.th.px(190))
        val = W.value_label(self.th, f"{init:.0f} {unit}")
        val.setFixedWidth(self.th.px(88))
        wrap = QWidget()
        wl = QHBoxLayout(wrap)
        wl.setContentsMargins(0, 0, 0, 0)
        wl.setSpacing(self.th.px(10))
        wl.addWidget(val)
        wl.addWidget(sl)
        sl.valueChangedF.connect(
            lambda v, l=val, u=unit: (l.setText(f"{v:.0f} {u}"),
                                      self._update_estimate()))
        row = group.add_row(label, wrap)
        return sl, row

    def _set_step(self, i):
        self.custom_ramps = None
        self.rate_step = [5, 10, 20, 40][i]
        self.btn_rec.setProperty('kind', 'plain')
        self.btn_rec.style().unpolish(self.btn_rec)
        self.btn_rec.style().polish(self.btn_rec)
        self._update_estimate()

    def _use_recommended(self):
        self.custom_ramps = list(self.RECOMMENDED)
        self.btn_rec.setProperty('kind', 'tinted')
        self.btn_rec.style().unpolish(self.btn_rec)
        self.btn_rec.style().polish(self.btn_rec)
        self._update_estimate()

    def _gen_ramps(self):
        """RECOMMENDED, or a uniform step up to max. The recommended list (5,
        then every 10 to 80) cannot be expressed as a uniform step, which is
        why it is a separate path."""
        if self.custom_ramps is not None:
            return list(self.custom_ramps)
        maxr = self.sl_max.valueF()
        ramps, r = [], self.rate_step
        while r <= maxr + 0.01 and len(ramps) < 20:
            ramps.append(int(round(r)))
            r += self.rate_step
        return ramps or [int(round(maxr))]

    def _update_estimate(self):
        tmin, tmax = self.sl_tmin.valueF(), self.sl_tmax.valueF()
        n_temps = max(1, int((tmax - tmin) / 10) + 1)
        ramps = self._gen_ramps()
        total = n_temps * (1 + len(ramps))
        # Relay is roughly 2-4 min per temperature; after it, one ramping test
        # per ramp - back-off plus a 60 s run, about 1.5 min each.
        est = n_temps * (3 + len(ramps) * 1.5)
        self.row_ramps.right.setText(", ".join(str(r) for r in ramps) + " °C/min")
        self.row_est.right.setText(f"{total} tests  ·  ~{est:.0f} min")

    def start(self):
        tmin, tmax = self.sl_tmin.valueF(), self.sl_tmax.valueF()
        if tmax <= tmin:
            core.error(self, "Invalid range", "'To' must be above 'From'.")
            return
        ramps = self._gen_ramps()
        n_temps = int((tmax - tmin) / 10) + 1
        if not core.ask(self, "Start calibration?",
                        f"{tmin:.0f}–{tmax:.0f} °C in 10 °C steps, ramps "
                        f"{', '.join(str(r) for r in ramps)} °C/min.\n"
                        f"{n_temps * (1 + len(ramps))} tests, roughly "
                        f"{n_temps * (3 + len(ramps) * 1.5):.0f} minutes. "
                        "It can be stopped at any time."):
            return
        self.app.start_autocal(tmin, tmax, ramps)
        self.accept()


# ════════════════════════════════════════════════════════════════════════
#  CALIBRATION PROGRESS
# ════════════════════════════════════════════════════════════════════════
class CalibrationDialog(Sheet):
    # Phases of one step, in firmware order: relay first measures the base
    # gains for the temperature, then rampprep/ramptest run in a loop for every
    # ramp in calRamps, tuning the heating branch per ramp.
    PHASES = [('heating', 'Heating'), ('stabil', 'Stabilising'),
              ('relay', 'Relay'), ('rampprep', 'Back-off'),
              ('ramptest', 'Ramp test')]

    def __init__(self, parent, theme, app):
        super().__init__(parent, theme, "Calibration",
                         "Relay autotuning - one test per temperature, then a "
                         "ramp test for each rate", 640, 700)
        self.app = app
        self.done_button("Hide")

        g = W.Group(theme)
        self.bar = W.Progress(theme)
        g.add_widget(self.bar, sep=False)
        self.row_now = g.add_row("Now", W.value_label(theme, "—", 'orange'))
        self.row_phase = g.add_row("Phase", W.value_label(theme, "—"))
        self.row_next = g.add_row("Next", W.value_label(theme, "—", 'teal'))
        self.row_eta = g.add_row("Remaining", W.value_label(theme, "—", 'yellow'))
        self.add(g)

        self.warn_group = W.Group(theme, "Warnings")
        self.add(self.warn_group)
        self.warn_group.hide()

        self.steps = W.Group(theme, "Temperatures")
        self.steps.card.setMinimumHeight(theme.px(200))
        self.add(self.steps)
        self.col.addStretch(1)

        stop = W.button(theme, "Abort calibration", 'stop', 'stop', self.abort)
        stop.setMinimumHeight(theme.px(46))
        self.footer.addWidget(stop)

        self._built = -1
        self._rows = []
        self.refresh()

    def _step_label(self, t, r):
        """Safe for relay, where r is a string - the old {r:.0f} formatting
        raised and the list never built."""
        try:
            if isinstance(r, str):
                return f"{t:.0f} °C"
            return f"{t:.0f} °C @ {r:.0f} °C/min"
        except Exception:
            return str(t)

    def refresh(self):
        app = self.app
        total = app.cal_total or len(app.cal_plan)
        cur = app.cal_current
        phase = getattr(app, 'cal_phase', None)

        self.bar.set(app._cal_progress_fraction(),
                     f"{min(cur, total)} / {total} temperatures")

        if app.cal_cur_temp is not None:
            extra = ""
            if phase in ('rampprep', 'ramptest') and isinstance(
                    app.cal_cur_ramp, (int, float)):
                extra = f"  @ {app.cal_cur_ramp:.0f} °C/min"
            self.row_now.right.setText(
                f"{app.cal_cur_temp:.0f} °C ({cur}/{total}){extra}")
        else:
            self.row_now.right.setText("waiting for device")

        self.row_phase.right.setText(
            dict(self.PHASES).get(phase, "—") if phase else "—")

        if 0 < cur < len(app.cal_plan):
            nt, nr = app.cal_plan[cur]
            self.row_next.right.setText(self._step_label(nt, nr))
        elif cur >= len(app.cal_plan) and app.cal_plan:
            self.row_next.right.setText("last")
        else:
            self.row_next.right.setText("—")

        # "COMPLETED" only when calibration has REALLY finished, not when the
        # last point has merely started.
        if not app.cal_running and cur >= total and total > 0:
            self.row_eta.right.setText("completed")
        else:
            eta = app._cal_eta()
            self.row_eta.right.setText(
                "—" if eta is None else
                "finalising…" if eta < 1 else
                f"~{int(eta // 60)} min {int(eta % 60)} s")

        self._refresh_warnings()
        self._refresh_steps(cur, phase)

    def _refresh_warnings(self):
        app = self.app
        lines = []
        warns = getattr(app, 'cal_warnings', [])
        if warns:
            def _w(w):
                t, cycles, amp = w
                if amp is not None and amp >= 140:
                    return f"{t:.0f} °C (even max excitation did not help)"
                return f"{t:.0f} °C"
            lines.append(("Relay found no oscillation",
                          ", ".join(_w(w) for w in warns) +
                          " — base values 10.0/0.30/0.80 were written instead "
                          "of measured ones."))
        rw = getattr(app, 'cal_ramp_warnings', [])
        if rw:
            def _r(w):
                t, r, err = w
                rt = f"{r:.0f} °C/min" if r is not None else "?"
                et = f", error {err:.1f} °C" if err is not None else ""
                return f"{t:.0f} °C @ {rt}{et}"
            lines.append(("Ramp test above threshold",
                          ", ".join(_r(w) for w in rw) +
                          " — the relay profile for those cells stays, and it "
                          "is still a real measurement."))
        self.clear_group(self.warn_group)
        if not lines:
            self.warn_group.hide()
            return
        self.warn_group.show()
        for title, sub in lines:
            r = self.warn_group.add_row(title, sub=sub)
            r.title.setStyleSheet(f"color: {self.th['orange']};")
            if r.sub:
                r.sub.setWordWrap(True)

    def _refresh_steps(self, cur, phase):
        app = self.app
        if self._built != len(app.cal_plan):
            self.clear_group(self.steps)
            self._rows = []
            for i, (t, r) in enumerate(app.cal_plan):
                row = self.steps.add_row(f"{i + 1}.  {self._step_label(t, r)}",
                                         W.value_label(self.th, "pending"))
                self._rows.append(row)
            self._built = len(app.cal_plan)

        warn_temps = {round(w[0]) for w in getattr(app, 'cal_warnings', [])}
        for i, row in enumerate(self._rows):
            step_no = i + 1
            temp = app.cal_plan[i][0] if i < len(app.cal_plan) else None
            failed = temp is not None and round(temp) in warn_temps
            if step_no < cur:
                row.right.setText("base (fail)" if failed else "done")
                row.right.setStyleSheet(
                    f"color: {self.th['red'] if failed else self.th['green']};")
            elif step_no == cur:
                row.right.setText(dict(self.PHASES).get(phase, "now"))
                row.right.setStyleSheet(f"color: {self.th['orange']};")
            else:
                row.right.setText("pending")
                row.right.setStyleSheet(f"color: {self.th['label3']};")

    def abort(self):
        if core.ask(self, "Abort calibration?",
                    "The board returns to manual control."):
            self.app.send("AUTOCALSTOP")
            self.app.send("STOP")
            self.app.cal_running = False
            self.accept()

    def closeEvent(self, e):
        self.app.cal_win = None
        e.accept()

    def accept(self):
        self.app.cal_win = None
        super().accept()
