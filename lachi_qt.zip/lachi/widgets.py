#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - the Cupertino widget set for PyQt6.

Qt ships Fusion, Windows and macOS styles; none of them is iOS. The pieces
that make an interface *read* as iOS are not colours - they are a handful of
specific components: the capsule switch with its animated knob, the grouped
list with hairline separators inset from the left, the segmented control, the
tab bar with its icon-over-label stack. Those are custom-painted here.

Everything else (buttons, fields, lists) is a stock Qt widget wearing the
stylesheet from theme.py, because Qt's own behaviour - focus, keyboard,
accessibility, IME - is worth more than a pixel-perfect repaint.

ONE RECURRING TRAP, worth stating once: the application stylesheet sets
font-size on the UNIVERSAL selector, and a QSS rule always beats
QWidget::setFont(). So anywhere a widget needs its own size, it is set through
that widget's own stylesheet with a TYPE selector (QLabel { ... }), which
out-specifies the universal one. Setting a QFont in code there looks like it
works and silently renders at body size.
"""
from __future__ import annotations

from PyQt6.QtCore import (QEasingCurve, QPropertyAnimation, QRectF, QSize, Qt,
                          QTimer, pyqtProperty, pyqtSignal)
from PyQt6.QtGui import (QColor, QFont, QFontMetrics, QPainter, QPainterPath,
                         QPen)
from PyQt6.QtWidgets import (QAbstractButton, QFrame, QGraphicsDropShadowEffect,
                             QHBoxLayout, QLabel, QLineEdit, QPushButton,
                             QSizePolicy, QSlider, QVBoxLayout, QWidget)

from . import icons
from .theme import PAD, R_CARD, R_CTRL, ROW_H, Theme


# ════════════════════════════════════════════════════════════════════════
#  SWITCH
# ════════════════════════════════════════════════════════════════════════
class Switch(QAbstractButton):
    """The iOS toggle: a 51x31 capsule with a white knob that slides.

    Apple's proportions exactly - track 51x31, knob 27 across with a 2pt
    inset - because at this size any deviation is what makes a copy look like
    a copy. The knob position is an animated property so the transition has
    the same 200 ms ease-out as the real thing.
    """
    W, H = 51.0, 31.0

    def __init__(self, theme: Theme, checked: bool = False, parent=None):
        super().__init__(parent)
        self.th = theme
        self.setCheckable(True)
        self.setChecked(checked)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._pos = 1.0 if checked else 0.0
        self._anim = QPropertyAnimation(self, b'knob', self)
        self._anim.setDuration(200)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.toggled.connect(self._animate)
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    # animated property -------------------------------------------------
    def _get_knob(self) -> float:
        return self._pos

    def _set_knob(self, v: float):
        self._pos = v
        self.update()

    knob = pyqtProperty(float, fget=_get_knob, fset=_set_knob)

    def _animate(self, on: bool):
        self._anim.stop()
        self._anim.setStartValue(self._pos)
        self._anim.setEndValue(1.0 if on else 0.0)
        self._anim.start()

    def setCheckedSilently(self, on: bool):
        """Reflect device state without firing toggled - the board is the
        source of truth for fans and polarity, not the widget."""
        self.blockSignals(True)
        self.setChecked(on)
        self.blockSignals(False)
        self._pos = 1.0 if on else 0.0
        self.update()

    # geometry ----------------------------------------------------------
    def sizeHint(self) -> QSize:
        s = self.th.scale
        return QSize(round(self.W * s), round(self.H * s))

    def paintEvent(self, _e):
        q = QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        s = self.th.scale
        w, h = self.W * s, self.H * s
        r = h / 2.0

        on_col = QColor(self.th['green'])
        off_col = QColor(self.th['grey4'])
        # cross-fade the track with the knob travel, as iOS does
        track = QColor(
            round(off_col.red() + (on_col.red() - off_col.red()) * self._pos),
            round(off_col.green() + (on_col.green() - off_col.green()) * self._pos),
            round(off_col.blue() + (on_col.blue() - off_col.blue()) * self._pos))
        if not self.isEnabled():
            track.setAlpha(110)

        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(track)
        q.drawRoundedRect(QRectF(0, 0, w, h), r, r)

        inset = 2.0 * s
        kd = h - 2 * inset
        kx = inset + self._pos * (w - 2 * inset - kd)
        # the knob carries a real shadow in iOS; a soft ellipse stands in
        q.setBrush(QColor(0, 0, 0, 38))
        q.drawEllipse(QRectF(kx, inset + 0.9 * s, kd, kd))
        q.setBrush(QColor('#FFFFFF'))
        q.drawEllipse(QRectF(kx, inset, kd, kd))
        q.end()

    def hitButton(self, pos):
        return self.rect().contains(pos)


# ════════════════════════════════════════════════════════════════════════
#  CARD, GROUP, ROW - the grouped-list vocabulary
# ════════════════════════════════════════════════════════════════════════
class Card(QFrame):
    """A white (or dark-grey) rounded block on the grey page."""

    def __init__(self, theme: Theme, parent=None, pad: int = 0, shadow=True,
                 inner=False):
        super().__init__(parent)
        self.th = theme
        self.setObjectName('card2' if inner else 'card')
        self.box = QVBoxLayout(self)
        p = theme.px(pad)
        self.box.setContentsMargins(p, p, p, p)
        self.box.setSpacing(0)
        if shadow and not inner:
            # iOS grouped cards are flat; a whisper of shadow keeps them from
            # dissolving into the background on a cheap panel.
            eff = QGraphicsDropShadowEffect(self)
            eff.setBlurRadius(theme.px(18))
            eff.setOffset(0, theme.px(2))
            eff.setColor(QColor(0, 0, 0, 40 if theme.dark else 18))
            self.setGraphicsEffect(eff)

    def add(self, w):
        self.box.addWidget(w)
        return w


class Separator(QFrame):
    """The hairline between list rows - inset from the left, as iOS insets it
    to the start of the label, not the edge of the card."""

    def __init__(self, theme: Theme, inset: int = 16, parent=None):
        super().__init__(parent)
        self.th = theme
        self.inset = inset
        self.setFixedHeight(1)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def paintEvent(self, _e):
        q = QPainter(self)
        col = QColor(self.th.solid('sep', 'card'))
        x = self.th.px(self.inset)
        q.fillRect(x, 0, self.width() - x, 1, col)
        q.end()


class Row(QWidget):
    """One list row: a title (and optional subtitle) on the left, whatever the
    caller supplies on the right."""

    def __init__(self, theme: Theme, title: str, right: QWidget | None = None,
                 sub: str | None = None, parent=None):
        super().__init__(parent)
        self.th = theme
        lay = QHBoxLayout(self)
        lay.setContentsMargins(theme.px(16), theme.px(9), theme.px(16), theme.px(9))
        lay.setSpacing(theme.px(10))

        col = QVBoxLayout()
        col.setSpacing(theme.px(1))
        col.setContentsMargins(0, 0, 0, 0)
        self.title = QLabel(title)
        self.title.setObjectName('rowTitle')
        col.addWidget(self.title)
        self.sub = None
        if sub:
            self.sub = QLabel(sub)
            self.sub.setObjectName('rowSub')
            col.addWidget(self.sub)
        lay.addLayout(col)
        lay.addStretch(1)

        self.right = right
        if right is not None:
            lay.addWidget(right, 0, Qt.AlignmentFlag.AlignVCenter)
        self.setMinimumHeight(theme.px(ROW_H))


def value_label(theme: Theme, text: str, color: str | None = None,
                mono: bool = False) -> QLabel:
    """The right-hand value of a row: secondary grey unless it means something."""
    lb = QLabel(text)
    lb.setObjectName('rowValue')
    if color:
        lb.setStyleSheet(f'color: {theme[color] if color in theme.p else color};')
    if mono:
        f = lb.font()
        f.setStyleHint(QFont.StyleHint.Monospace)
        lb.setFont(f)
    lb.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
    return lb


class Group(QWidget):
    """Header + card + rows with separators: iOS's inset grouped section."""

    def __init__(self, theme: Theme, header: str | None = None,
                 footer: str | None = None, parent=None):
        super().__init__(parent)
        self.th = theme
        self._rows = 0
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        if header:
            h = QLabel(header.upper())
            h.setObjectName('groupHeader')
            outer.addWidget(h)

        self.card = Card(theme)
        outer.addWidget(self.card)

        if footer:
            f = QLabel(footer)
            f.setObjectName('groupFooter')
            f.setWordWrap(True)
            outer.addWidget(f)

    def add_row(self, title: str, right: QWidget | None = None,
                sub: str | None = None) -> Row:
        if self._rows:
            self.card.box.addWidget(Separator(self.th))
        r = Row(self.th, title, right, sub)
        self.card.box.addWidget(r)
        self._rows += 1
        return r

    def add_widget(self, w: QWidget, sep: bool = True) -> QWidget:
        """Anything that is not a plain row - a chart, a list, a button bar."""
        if self._rows and sep:
            self.card.box.addWidget(Separator(self.th, inset=0))
        self.card.box.addWidget(w)
        self._rows += 1
        return w


# ════════════════════════════════════════════════════════════════════════
#  STAT TILE
# ════════════════════════════════════════════════════════════════════════
class Stat(Card):
    """The big readout: caption, a large tinted number, a small unit."""

    def __init__(self, theme: Theme, title: str, unit: str, color: str,
                 parent=None):
        super().__init__(theme, parent, pad=0)
        self.color = color
        lay = QVBoxLayout()
        lay.setContentsMargins(theme.px(14), theme.px(11), theme.px(14),
                               theme.px(12))
        lay.setSpacing(theme.px(2))

        self.cap = QLabel(title.upper())
        self.cap.setObjectName('statTitle')
        lay.addWidget(self.cap)

        row = QHBoxLayout()
        row.setSpacing(theme.px(4))
        row.setContentsMargins(0, 0, 0, 0)
        self.val = QLabel('--')
        self._paint_value(theme, color)
        row.addWidget(self.val, 0, Qt.AlignmentFlag.AlignBottom)

        self.unit = QLabel(unit)
        self.unit.setObjectName('statUnit')
        row.addWidget(self.unit, 0, Qt.AlignmentFlag.AlignBottom)
        row.addStretch(1)
        lay.addLayout(row)
        self.box.addLayout(lay)

    def _paint_value(self, theme: Theme, color: str):
        # A TYPE selector, not a bare declaration: the application sheet styles
        # the universal selector, and on equal specificity Qt keeps the app
        # rule - so the size has to out-specify it.
        self.val.setStyleSheet(
            "QLabel { color: %s; font-size: %dpt; font-weight: 700; }"
            % (theme[color] if color in theme.p else color, theme.pt('title1')))

    def set(self, text: str, color: str | None = None):
        self.val.setText(text)
        if color:
            self._paint_value(self.th, color)


# ════════════════════════════════════════════════════════════════════════
#  SEGMENTED CONTROL
# ════════════════════════════════════════════════════════════════════════
class Segmented(QWidget):
    """iOS's segmented control: a grey trough with a white puck that slides.

    Used wherever the Tkinter app had a row of radio-ish buttons (chart
    window, archive X-axis mode, UI scale).
    """
    changed = pyqtSignal(int)

    def __init__(self, theme: Theme, items: list[str], index: int = 0,
                 parent=None):
        super().__init__(parent)
        self.th = theme
        self.items = list(items)
        self.index = index
        self._puck = float(index)
        self._anim = QPropertyAnimation(self, b'puck', self)
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(theme.px(32))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def _get_puck(self) -> float:
        return self._puck

    def _set_puck(self, v: float):
        self._puck = v
        self.update()

    puck = pyqtProperty(float, fget=_get_puck, fset=_set_puck)

    def setIndex(self, i: int, emit: bool = True):
        i = max(0, min(len(self.items) - 1, int(i)))
        if i == self.index:
            return
        self.index = i
        self._anim.stop()
        self._anim.setStartValue(self._puck)
        self._anim.setEndValue(float(i))
        self._anim.start()
        if emit:
            self.changed.emit(i)

    def setItems(self, items: list[str], index: int = 0):
        self.items = list(items)
        self.index = max(0, min(len(items) - 1, index))
        self._puck = float(self.index)
        self.update()

    def mousePressEvent(self, e):
        if not self.items:
            return
        w = self.width() / len(self.items)
        self.setIndex(int(e.position().x() // w))

    def sizeHint(self) -> QSize:
        fm = QFontMetrics(self.font())
        w = sum(fm.horizontalAdvance(t) + self.th.px(26) for t in self.items)
        return QSize(max(w, self.th.px(160)), self.th.px(32))

    def paintEvent(self, _e):
        if not self.items:
            return
        q = QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        r = self.th.px(9)

        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(QColor(self.th.solid('fill', 'bg')))
        q.drawRoundedRect(QRectF(0, 0, w, h), r, r)

        seg = w / len(self.items)
        pad = self.th.px(2)
        px = pad + self._puck * seg
        q.setBrush(QColor(0, 0, 0, 30))
        q.drawRoundedRect(QRectF(px, pad + self.th.px(1), seg - 2 * pad,
                                 h - 2 * pad), r - pad, r - pad)
        q.setBrush(QColor('#FFFFFF' if not self.th.dark else '#636366'))
        q.drawRoundedRect(QRectF(px, pad, seg - 2 * pad, h - 2 * pad),
                          r - pad, r - pad)

        f = QFont(self.font())
        f.setPointSize(self.th.pt('subhead'))
        for i, t in enumerate(self.items):
            sel = (i == self.index)
            f.setWeight(QFont.Weight.DemiBold if sel else QFont.Weight.Normal)
            q.setFont(f)
            q.setPen(QColor(self.th['label'] if sel
                            else self.th.solid('label2', 'bg')))
            q.drawText(QRectF(i * seg, 0, seg, h),
                       int(Qt.AlignmentFlag.AlignCenter), t)
        q.end()


# ════════════════════════════════════════════════════════════════════════
#  TAB BAR
# ════════════════════════════════════════════════════════════════════════
class TabBar(QWidget):
    """The iPhone tab bar: hairline on top, icon over an 11pt label, the
    active item tinted blue. Fixed to the bottom of the window."""
    changed = pyqtSignal(int)

    def __init__(self, theme: Theme, items: list[tuple[str, str]],
                 parent=None):
        super().__init__(parent)
        self.th = theme
        self.items = items          # [(icon_name, label), ...]
        self.index = 0
        self._hover = -1
        self.setMouseTracking(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(theme.px(56))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def setIndex(self, i: int, emit: bool = True):
        if i == self.index or not (0 <= i < len(self.items)):
            return
        self.index = i
        self.update()
        if emit:
            self.changed.emit(i)

    def mousePressEvent(self, e):
        w = self.width() / len(self.items)
        self.setIndex(int(e.position().x() // w))

    def mouseMoveEvent(self, e):
        w = self.width() / len(self.items)
        h = int(e.position().x() // w)
        if h != self._hover:
            self._hover = h
            self.update()

    def leaveEvent(self, _e):
        self._hover = -1
        self.update()

    def paintEvent(self, _e):
        q = QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()

        q.fillRect(0, 0, w, h, QColor(self.th['bar']))
        q.fillRect(0, 0, w, 1, QColor(self.th.solid('sep', 'bar')))

        seg = w / len(self.items)
        isz = self.th.px(25)
        f = QFont(self.font())
        f.setPointSize(max(7, round(10 * self.th.scale)))
        for i, (ic, label) in enumerate(self.items):
            active = (i == self.index)
            col = self.th['blue'] if active else self.th.solid('label2', 'bar')
            px = icons.pixmap(ic, isz, col, 1.9 if not active else 2.15)
            x = i * seg
            q.drawPixmap(int(x + (seg - isz) / 2), self.th.px(7), isz, isz, px)
            f.setWeight(QFont.Weight.DemiBold if active else QFont.Weight.Medium)
            q.setFont(f)
            q.setPen(QColor(col))
            q.drawText(QRectF(x, h - self.th.px(21), seg, self.th.px(16)),
                       int(Qt.AlignmentFlag.AlignCenter), label)
        q.end()


# ════════════════════════════════════════════════════════════════════════
#  PROGRESS
# ════════════════════════════════════════════════════════════════════════
class Progress(QWidget):
    """A determinate bar with its caption centred on top, iOS-style: a rounded
    trough, a tinted fill, no chrome."""

    def __init__(self, theme: Theme, color: str = 'purple', parent=None):
        super().__init__(parent)
        self.th = theme
        self.color = color
        self.frac = 0.0
        self.text = ""
        self.setFixedHeight(theme.px(34))
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

    def set(self, frac: float, text: str = ""):
        self.frac = max(0.0, min(1.0, float(frac)))
        self.text = text
        self.update()

    def paintEvent(self, _e):
        q = QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        m = self.th.px(12)
        w, h = self.width() - 2 * m, self.height()
        bh = self.th.px(8)
        y = (h - bh) / 2
        r = bh / 2
        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(QColor(self.th.solid('fill', 'card')))
        q.drawRoundedRect(QRectF(m, y, w, bh), r, r)
        if self.frac > 0:
            q.setBrush(QColor(self.th[self.color]))
            q.drawRoundedRect(QRectF(m, y, max(bh, w * self.frac), bh), r, r)
        if self.text:
            f = QFont(self.font())
            f.setPointSize(self.th.pt('caption'))
            f.setWeight(QFont.Weight.DemiBold)
            q.setFont(f)
            q.setPen(QColor(self.th.solid('label2', 'card')))
            q.drawText(QRectF(m, 0, w, h),
                       int(Qt.AlignmentFlag.AlignCenter), self.text)
        q.end()


# ════════════════════════════════════════════════════════════════════════
#  MISC
# ════════════════════════════════════════════════════════════════════════
class Chip(QWidget):
    """The capsule in the header: a coloured dot and a word. Connection state."""

    def __init__(self, theme: Theme, text: str = 'OFFLINE',
                 color: str = 'red', parent=None):
        super().__init__(parent)
        self.th = theme
        self.text_ = text
        self.color = color
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)

    def set(self, text: str, color: str):
        self.text_, self.color = text, color
        self.updateGeometry()
        self.update()

    def _font(self) -> QFont:
        f = QFont(self.font())
        f.setPointSize(self.th.pt('caption'))
        f.setWeight(QFont.Weight.DemiBold)
        return f

    def sizeHint(self) -> QSize:
        fm = QFontMetrics(self._font())
        return QSize(fm.horizontalAdvance(self.text_) + self.th.px(34),
                     self.th.px(26))

    def paintEvent(self, _e):
        q = QPainter(self)
        q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        w, h = self.width(), self.height()
        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(QColor(self.th.solid('fill', 'bg')))
        q.drawRoundedRect(QRectF(0, 0, w, h), h / 2, h / 2)
        d = self.th.px(7)
        q.setBrush(QColor(self.th[self.color]))
        q.drawEllipse(QRectF(self.th.px(9), (h - d) / 2, d, d))
        q.setFont(self._font())
        q.setPen(QColor(self.th.solid('label2', 'bg')))
        q.drawText(QRectF(self.th.px(22), 0, w - self.th.px(30), h),
                   int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft),
                   self.text_)
        q.end()


def button(theme: Theme, text: str, kind: str = 'plain', icon_name: str = '',
           on_click=None, parent=None) -> QPushButton:
    """A stock QPushButton wearing one of the stylesheet's `kind` looks."""
    b = QPushButton(text, parent)
    b.setProperty('kind', kind)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if icon_name:
        tint = {'filled': '#FFFFFF', 'go': '#FFFFFF', 'stop': '#FFFFFF',
                'warn': '#FFFFFF'}.get(kind, theme['blue'])
        if kind == 'destructive':
            tint = theme['red']
        b.setIcon(icons.icon(icon_name, theme.px(19), tint))
        b.setIconSize(QSize(theme.px(19), theme.px(19)))
    if on_click:
        b.clicked.connect(on_click)
    return b


def icon_button(theme: Theme, icon_name: str, tip: str = '', on_click=None,
                color: str = 'blue', size: int = 22, parent=None) -> QPushButton:
    b = QPushButton(parent)
    b.setProperty('kind', 'icon')
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    tint = theme[color] if color in theme.p else color
    # rgba() is a stylesheet colour, not something QColor can parse; flatten
    # the label tints against the bar so the glyph is not painted flat black.
    if tint.startswith('rgba'):
        tint = theme.solid(color, 'bg')
    b.setIcon(icons.icon(icon_name, theme.px(size), tint))
    b.setIconSize(QSize(theme.px(size), theme.px(size)))
    b.setFixedSize(theme.px(size + 14), theme.px(size + 14))
    if tip:
        b.setToolTip(tip)
    if on_click:
        b.clicked.connect(on_click)
    return b


class Slider(QSlider):
    """A horizontal QSlider that works in floats, since every physical value
    in this app (setpoint, rate, fan speed) is one."""
    valueChangedF = pyqtSignal(float)

    def __init__(self, vmin: float, vmax: float, step: float = 0.1,
                 parent=None):
        super().__init__(Qt.Orientation.Horizontal, parent)
        self.k = step
        self.setRange(round(vmin / step), round(vmax / step))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        # The knob is 22px across and overhangs the 4px groove, so the widget
        # needs room for it or Qt clips the knob away entirely.
        self.setMinimumHeight(26)
        self.valueChanged.connect(lambda v: self.valueChangedF.emit(v * self.k))

    def valueF(self) -> float:
        return self.value() * self.k

    def setValueF(self, v: float, silent: bool = False):
        if silent:
            self.blockSignals(True)
        self.setValue(round(v / self.k))
        if silent:
            self.blockSignals(False)


class SliderField:
    """A list row carrying a slider and an editable number.

    Keeps the get()/set(v, silent)/set_enabled() API of the Tkinter widget it
    replaces, so every call site in the instrument logic - including the series
    state machine, which drives these from code - is unchanged.

    The value is editable as text as well as draggable, because a setpoint is
    something you often know exactly ("80.0", not "somewhere near the right of
    the track"), and the debounce exists because dragging a slider that sends a
    serial command per pixel would flood the link.
    """

    def __init__(self, group: 'Group', theme: Theme, label: str,
                 vmin: float, vmax: float, vinit: float, unit: str = "",
                 dec: int = 1, color: str = 'blue', on_change=None,
                 sub: str | None = None, debounce_ms: int = 120):
        self.th = theme
        self.unit = unit
        self.dec = dec
        self.on_change = on_change
        self.vmin, self.vmax = vmin, vmax
        self._debounce = QTimer()
        self._debounce.setSingleShot(True)
        self._debounce.setInterval(debounce_ms)
        self._debounce.timeout.connect(self._emit)
        self._pending = None

        step = 10 ** (-dec) if dec else 1.0
        self.slider = Slider(vmin, vmax, step)
        self.slider.setFixedWidth(theme.px(172))
        self.slider.setValueF(vinit, silent=True)

        self.entry = QLineEdit(f"{vinit:.{dec}f}")
        self.entry.setFixedWidth(theme.px(74))
        self.entry.setStyleSheet(
            "QLineEdit { font-size: %dpt; }" % theme.pt('subhead'))
        self.entry.setAlignment(Qt.AlignmentFlag.AlignRight
                                | Qt.AlignmentFlag.AlignVCenter)
        self.entry.editingFinished.connect(self._on_entry)

        unit_lb = QLabel(unit)
        unit_lb.setObjectName('rowValue')
        unit_lb.setStyleSheet(
            "QLabel { font-size: %dpt; }" % theme.pt('footnote'))
        unit_lb.setFixedWidth(theme.px(62))

        wrap = QWidget()
        lay = QHBoxLayout(wrap)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(theme.px(8))
        lay.addWidget(self.entry)
        lay.addWidget(unit_lb)
        lay.addWidget(self.slider)

        self.row = group.add_row(label, wrap, sub=sub)
        self.slider.valueChangedF.connect(self._on_slide)

    # -- API -------------------------------------------------------------
    def get(self) -> float:
        return round(self.slider.valueF(), self.dec)

    def set(self, v: float, silent: bool = True):
        v = max(self.vmin, min(self.vmax, float(v)))
        self.slider.setValueF(v, silent=True)
        self.entry.setText(f"{v:.{self.dec}f}")
        if not silent and self.on_change:
            self.on_change(self.get())

    def set_enabled(self, en: bool):
        self.slider.setEnabled(en)
        self.entry.setEnabled(en)
        self.row.title.setEnabled(en)

    # -- internals -------------------------------------------------------
    def _on_slide(self, v: float):
        self.entry.setText(f"{v:.{self.dec}f}")
        self._pending = round(v, self.dec)
        self._debounce.start()

    def _on_entry(self):
        try:
            v = float(self.entry.text().replace(',', '.'))
        except ValueError:
            self.entry.setText(f"{self.get():.{self.dec}f}")
            return
        v = max(self.vmin, min(self.vmax, v))
        self.slider.setValueF(v, silent=True)
        self.entry.setText(f"{v:.{self.dec}f}")
        self._pending = round(v, self.dec)
        self._emit()

    def _emit(self):
        if self._pending is not None and self.on_change:
            self.on_change(self._pending)
        self._pending = None


class HeaderBar(QWidget):
    """The large-title header: wordmark, subtitle, status chip, appearance
    toggle. iOS puts the large title inside the scroll view; here it is
    pinned, because an instrument's connection state must never scroll away.
    """

    def __init__(self, theme: Theme, parent=None):
        super().__init__(parent)
        self.th = theme
        lay = QHBoxLayout(self)
        lay.setContentsMargins(theme.px(PAD + 4), theme.px(10),
                               theme.px(PAD), theme.px(6))
        lay.setSpacing(theme.px(8))

        col = QVBoxLayout()
        col.setSpacing(0)
        self.title = QLabel('LACHI')
        self.title.setStyleSheet(
            "QLabel { font-size: %dpt; font-weight: 700; }"
            % theme.pt('largeTitle'))
        col.addWidget(self.title)

        self.sub = QLabel('photocurrent & pyrocurrent bench')
        self.sub.setStyleSheet(
            f"color: {theme['label2']}; font-size: {theme.pt('footnote')}pt;")
        col.addWidget(self.sub)
        lay.addLayout(col)
        lay.addStretch(1)

        self.chip = Chip(theme, 'OFFLINE', 'red')
        lay.addWidget(self.chip, 0, Qt.AlignmentFlag.AlignVCenter)
        self.appearance = icon_button(
            theme, 'moon' if not theme.dark else 'sun', 'Light / dark')
        lay.addWidget(self.appearance, 0, Qt.AlignmentFlag.AlignVCenter)
