#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - the chart panel: matplotlib embedded natively in Qt.

THIS IS THE REASON THE APP IS PyQt AND NOT FLET
-----------------------------------------------
Flet renders matplotlib by rasterising the figure and shipping the image to a
Flutter canvas. That is fine for a dashboard tile and wrong for an instrument:
this bench draws a live trace four times a second and the operator zooms into
it with the mouse while it runs. FigureCanvasQTAgg is a real Qt widget - the
figure is blitted into the window, and matplotlib's own event system delivers
the mouse straight to data coordinates, with no round trip.

WHAT IS HERE
------------
  ChartNav    the three gestures - drag to zoom, wheel to zoom, right-click to
              reset - carried over unchanged from the Tkinter app, including
              the lock that stops a live redraw from throwing a zoom away
  style_axes  frameless axes with the scale drawn inside the plot
  ChartPanel  the Qt widget: figure + canvas + nav + export
  print_theme anything that leaves the app is drawn on white
"""
from __future__ import annotations

import contextlib

import matplotlib
matplotlib.use('QtAgg')
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
from matplotlib.figure import Figure
from matplotlib.patches import Rectangle
from PyQt6.QtCore import Qt
from PyQt6.QtWidgets import QSizePolicy, QVBoxLayout, QWidget

from .theme import Theme


# ════════════════════════════════════════════════════════════════════════
#  COLOURS THE PLOTTING CODE READS
# ════════════════════════════════════════════════════════════════════════
# Every drawing routine reads these at DRAW time, never caches them. That is
# what lets print_theme() swap the whole palette for the duration of a save
# and get a correctly restyled figure out of the same plotting code.
def screen_colors(theme: Theme) -> dict:
    """The chart palette for the current appearance."""
    return {
        'face':   theme['card'],
        'text':   theme.solid('label', 'card'),
        'dim':    theme.solid('label2', 'card'),
        'dim2':   theme.solid('label3', 'card'),
        'grid':   theme.solid('grid', 'card'),
        'blue':   theme['blue'],       # temperature
        'orange': theme['orange'],     # setpoint
        'yellow': theme['yellow'],     # rate
        'green':  theme['green'],      # PWM
        'red':    theme['red'],
        'cyan':   theme['cyan'],       # second sensor / cooling
        'purple': theme['purple'],
        'teal':   theme['teal'],
        'pink':   theme['pink'],
        'band':   theme['blue'],       # the rubber band
    }


# Print: near-black text on white, and accents darkened until they hold up on
# paper. The keys match screen_colors() exactly, so the plotting code does not
# know which one it is drawing with.
PRINT_COLORS = {
    'face':   '#FFFFFF',
    'text':   '#101010',
    'dim':    '#2A2A2A',
    'dim2':   '#666666',
    'grid':   '#CCCCCC',
    'blue':   '#1F6FB4',
    'orange': '#D2691E',
    'yellow': '#B8860B',
    'green':  '#2E7D32',
    'red':    '#B3261E',
    'cyan':   '#00796B',
    'purple': '#6A3FA0',
    'teal':   '#0F7B8A',
    'pink':   '#B03060',
    'band':   '#8A7326',
}


# ════════════════════════════════════════════════════════════════════════
#  NAVIGATION
# ════════════════════════════════════════════════════════════════════════
class ChartNav:
    """Drag to zoom, wheel to zoom, right-click to reset.

    Replaces matplotlib's NavigationToolbar, which brings its own icon set and
    its own chrome, and whose zoom is modal - click the magnifier first, THEN
    drag. Nobody wants that step on a live trace.

    The live chart is the case that makes this non-trivial: its redraw clears
    the axes four times a second, which would discard a manual zoom on the next
    frame. So a zoom LOCKS the view, and the redraw calls restore() to re-apply
    the saved limits instead of autoscaling, until a right-click releases it.
    """
    WHEEL_STEP = 1.18            # zoom factor per wheel notch

    def __init__(self, canvas, axes, on_change=None, share_x=True,
                 colors=None):
        self.canvas = canvas
        self.axes = list(axes)
        self.on_change = on_change
        self.share_x = share_x
        self.colors = colors if colors is not None else {'band': '#007AFF'}
        self.locked = False
        self._lim = {}
        self._press = None
        self._rect = None
        c = canvas.mpl_connect
        c('button_press_event', self._on_press)
        c('motion_notify_event', self._on_motion)
        c('button_release_event', self._on_release)
        c('scroll_event', self._on_scroll)

    # ── state ───────────────────────────────────────────────────────────
    def remember(self):
        self._lim = {ax: (ax.get_xlim(), ax.get_ylim()) for ax in self.axes}

    def restore(self):
        """Called by the redraw AFTER re-plotting: re-apply a locked view."""
        if not self.locked:
            return
        for ax, (xl, yl) in self._lim.items():
            ax.set_xlim(xl)
            ax.set_ylim(yl)

    def reset(self):
        self.locked = False
        self._lim = {}
        for ax in self.axes:
            ax.relim()
            ax.autoscale(True)
        if self.on_change:
            self.on_change()
        else:
            self.canvas.draw_idle()

    def _lock(self):
        self.locked = True
        self.remember()
        self.canvas.draw_idle()

    # ── rubber band ─────────────────────────────────────────────────────
    def _on_press(self, e):
        if e.button == 3:                      # right button - back to auto
            self.reset()
            return
        if e.button == 1 and e.inaxes in self.axes:
            self._press = (e.xdata, e.ydata, e.inaxes)

    def _on_motion(self, e):
        if not self._press or e.inaxes is not self._press[2] or e.xdata is None:
            return
        x0, y0, ax = self._press
        if self._rect is not None:
            try:
                self._rect.remove()
            except Exception:
                pass
        band = self.colors.get('band', '#007AFF')
        self._rect = Rectangle((min(x0, e.xdata), min(y0, e.ydata)),
                               abs(e.xdata - x0), abs(e.ydata - y0),
                               fill=True, fc=band, ec=band,
                               alpha=0.16, lw=1.0, zorder=50)
        ax.add_patch(self._rect)
        self.canvas.draw_idle()

    def _on_release(self, e):
        if not self._press:
            return
        x0, y0, ax = self._press
        self._press = None
        if self._rect is not None:
            try:
                self._rect.remove()
            except Exception:
                pass
            self._rect = None
        if e.xdata is None or e.inaxes is not ax:
            self.canvas.draw_idle()
            return
        # A click, not a drag - ignore, so a stray click cannot zoom to a point
        if abs(e.x - ax.transData.transform((x0, y0))[0]) < 8 and \
           abs(e.y - ax.transData.transform((x0, y0))[1]) < 8:
            self.canvas.draw_idle()
            return
        xlo, xhi = sorted((x0, e.xdata))
        ylo, yhi = sorted((y0, e.ydata))
        for a in self.axes:
            if self.share_x or a is ax:
                a.set_xlim(xlo, xhi)
            if a is ax:
                a.set_ylim(ylo, yhi)
        self._lock()

    # ── wheel ───────────────────────────────────────────────────────────
    def _on_scroll(self, e):
        ax = e.inaxes
        if ax not in self.axes:
            return
        f = 1 / self.WHEEL_STEP if e.button == 'up' else self.WHEEL_STEP
        for a in self.axes:
            if self.share_x or a is ax:
                lo, hi = a.get_xlim()
                cx = e.xdata if e.xdata is not None else (lo + hi) / 2
                a.set_xlim(cx - (cx - lo) * f, cx + (hi - cx) * f)
            if a is ax and e.ydata is not None:
                lo, hi = a.get_ylim()
                a.set_ylim(e.ydata - (e.ydata - lo) * f,
                           e.ydata + (hi - e.ydata) * f)
        self._lock()


# ════════════════════════════════════════════════════════════════════════
#  AXIS STYLE
# ════════════════════════════════════════════════════════════════════════
def _align_inside(ax):
    """Pull the tick labels inside the plotting area.

    This has to run on every DRAW, not once at setup: matplotlib recomputes
    tick locations lazily, so alignment applied to the labels that existed at
    style time is thrown away as soon as the data - and with it the tick
    positions - change. Without this the bottom-most y label and the whole x
    row hang outside the axes and are clipped by the canvas edge.
    """
    for t in ax.get_yticklabels():
        t.set_horizontalalignment('left')
        t.set_verticalalignment('bottom')
    for t in ax.get_xticklabels():
        t.set_verticalalignment('bottom')
        t.set_horizontalalignment('left')


def style_axes(ax, cs: dict, xunit=None, yunit=None, show_x=True,
               fontsize=8, grid=True):
    """Frameless axes with the scale drawn INSIDE the plot.

    A framed axis spends a wide margin on spines, tick marks and axis titles;
    on a panel this size that margin is a noticeable slice of the chart. So
    there is no frame, the tick labels sit just inside the plotting area, and
    the unit is a small corner caption rather than a full axis title. The
    captions are held off the very corners so they cannot land on top of the
    first tick label.
    """
    ax.set_facecolor(cs['face'])
    for sp in ax.spines.values():
        sp.set_visible(False)
    ax.tick_params(axis='y', direction='in', length=0, pad=-4,
                   colors=cs['dim'], labelsize=fontsize)
    ax.tick_params(axis='x', direction='in', length=0, pad=-13,
                   colors=cs['dim'], labelsize=fontsize, labelbottom=show_x)
    ax.set_xlabel('')
    ax.set_ylabel('')
    if grid:
        ax.grid(True, color=cs['grid'], lw=0.8, alpha=1.0)
        ax.set_axisbelow(True)
    _align_inside(ax)
    if not getattr(ax, '_inside_hooked', False):
        ax.figure.canvas.mpl_connect('draw_event',
                                     lambda e, a=ax: _align_inside(a))
        ax._inside_hooked = True
    if yunit:
        ax.text(0.008, 0.955, yunit, transform=ax.transAxes, ha='left',
                va='top', color=cs['dim2'], fontsize=fontsize)
    if xunit and show_x:
        ax.text(0.995, 0.075, xunit, transform=ax.transAxes, ha='right',
                va='bottom', color=cs['dim2'], fontsize=fontsize)


def style_legend(ax, cs: dict, loc='best', fontsize=8, ncol=1):
    """A frameless legend in the label colour - no box, no shadow."""
    handles, labels = ax.get_legend_handles_labels()
    if not handles:
        return None
    leg = ax.legend(loc=loc, frameon=False, fontsize=fontsize, ncol=ncol,
                    handlelength=1.6, borderpad=0.2, labelspacing=0.3,
                    columnspacing=1.1)
    for t in leg.get_texts():
        t.set_color(cs['dim'])
    return leg


# ════════════════════════════════════════════════════════════════════════
#  THE PANEL
# ════════════════════════════════════════════════════════════════════════
class Canvas(FigureCanvasQTAgg):
    """FigureCanvasQTAgg that accepts the wheel and keeps a transparent
    background, so the card's rounded corners show through."""

    def __init__(self, fig):
        super().__init__(fig)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setSizePolicy(QSizePolicy.Policy.Expanding,
                           QSizePolicy.Policy.Expanding)
        self.setStyleSheet('background: transparent;')


class ChartPanel(QWidget):
    """A figure, its canvas and its navigation, sized to fill its container.

    `cs` is the live colour dict the owner's plotting code reads. export()
    swaps it for the print palette, calls the redraw, saves, and swaps back -
    the same mechanism the Tkinter app used, and the reason a saved PNG is
    black-on-white without a second copy of the plotting code.
    """

    def __init__(self, theme: Theme, nrows: int = 1, height_ratios=None,
                 hspace: float = 0.06, share_x: bool = True,
                 margins=(0.052, 0.045, 0.995, 0.985), figsize=(9.0, 3.4),
                 parent=None):
        super().__init__(parent)
        self.th = theme
        self.cs = screen_colors(theme)
        self._margins = margins

        # figsize x dpi IS the canvas's size hint, and a Qt layout honours it.
        # Left at matplotlib's 6.4x4.8 default the chart claims 480 px of a
        # scrolling column and pushes everything below it off the screen.
        self.fig = Figure(figsize=figsize, dpi=100, facecolor=self.cs['face'])
        self.canvas = Canvas(self.fig)

        gs = self.fig.add_gridspec(nrows, 1, height_ratios=height_ratios,
                                   hspace=hspace,
                                   left=margins[0], bottom=margins[1],
                                   right=margins[2], top=margins[3])
        self.axes = []
        first = None
        for i in range(nrows):
            ax = self.fig.add_subplot(gs[i], sharex=first if share_x else None)
            if first is None:
                first = ax
            ax.set_facecolor(self.cs['face'])
            self.axes.append(ax)
        self.ax = self.axes[0]

        self.nav = ChartNav(self.canvas, self.axes, on_change=self._on_nav,
                            share_x=share_x, colors=self.cs)
        self.redraw = None           # the owner assigns its plotting routine

        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.addWidget(self.canvas)

    # ── appearance ──────────────────────────────────────────────────────
    def retheme(self, theme: Theme):
        """Follow a light/dark flip. The colour dict is mutated IN PLACE so
        that ChartNav and any routine holding a reference see the new values."""
        self.th = theme
        self.cs.clear()
        self.cs.update(screen_colors(theme))
        self.fig.set_facecolor(self.cs['face'])
        for ax in self.axes:
            ax.set_facecolor(self.cs['face'])
        if self.redraw:
            self.redraw()
        else:
            self.canvas.draw_idle()

    def _on_nav(self):
        if self.redraw:
            self.redraw()
        else:
            self.canvas.draw_idle()

    def draw(self):
        self.canvas.draw_idle()

    # ── export ──────────────────────────────────────────────────────────
    @contextlib.contextmanager
    def print_theme(self):
        """Swap the palette to the print one for the duration of a save.

        The plotting code reads self.cs at draw time, so mutating it in place
        and re-running the redraw restyles the whole figure - lines, ticks,
        labels, legend, grid - and none of that code needs to know.
        """
        saved = dict(self.cs)
        saved_face = self.fig.get_facecolor()
        self.cs.clear()
        self.cs.update(PRINT_COLORS)
        self.fig.set_facecolor('white')
        for ax in self.axes:
            ax.set_facecolor('white')
        try:
            if self.redraw:
                self.redraw()
            yield
        finally:
            self.cs.clear()
            self.cs.update(saved)
            self.fig.set_facecolor(saved_face)
            for ax in self.axes:
                ax.set_facecolor(saved['face'])
            if self.redraw:
                self.redraw()

    def export(self, path: str, dpi: int = 200, size=None):
        """Save to PNG / PDF / SVG on a white background.

        `size` temporarily resizes the figure, so a 1200-px-wide on-screen
        panel can be saved at a sensible aspect ratio for a report.
        """
        old = self.fig.get_size_inches()
        with self.print_theme():
            if size:
                self.fig.set_size_inches(*size)
            self.fig.savefig(path, dpi=dpi, facecolor='white',
                             edgecolor='none', bbox_inches='tight',
                             pad_inches=0.18)
            if size:
                self.fig.set_size_inches(old)
        return path
