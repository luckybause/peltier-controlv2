#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - iOS / macOS look for PyQt6.

WHY THIS FILE EXISTS
--------------------
Qt has no Cupertino widget set. What it does have is a stylesheet engine that
is close enough to CSS that Apple's actual design tokens can be expressed
directly: corner radii, system greys, separator hairlines, the two grouped
backgrounds. So the whole visual identity lives here, in ONE place, as data -
and every widget in the app reads it. Switching light/dark is then a matter of
re-emitting the stylesheet, not rebuilding the UI.

The palette is not "inspired by" iOS - these are the published system colours
from Apple's Human Interface Guidelines, in both appearances.

A NOTE ON COLOUR STRINGS
------------------------
Qt stylesheets take CSS notation: #RRGGBB, or rgba(r,g,b,a) with a 0-1 alpha.
Apple publishes the translucent labels as percentages, so they are stored here
as rgba() and converted for matplotlib (which wants #RRGGBBAA) by mpl().

Note that Qt reads a NINE-digit hex string as #AARRGGBB, not #RRGGBBAA, so
Apple's published systemFill values cannot be pasted in that form - they come
out as an entirely different colour. They are written as rgba() below.
"""
from __future__ import annotations

# ── SYSTEM PALETTE ──────────────────────────────────────────────────────
# Apple's system colours. Keys are semantic, not literal, so a widget asks
# for "the separator" and gets the right one for the current appearance.
LIGHT = {
    # backgrounds - iOS "grouped" style: the page is grey, the cards are white
    'bg':        '#F2F2F7',   # systemGroupedBackground
    'card':      '#FFFFFF',   # secondarySystemGroupedBackground
    'card2':     '#F9F9F9',   # a card sitting on a card
    'fill':      'rgba(120,120,128,0.12)',  # systemFill - grooves, chips
    'sep':       '#C6C6C8',   # separator (the hairline between list rows)
    'sep2':      '#E5E5EA',   # opaqueSeparator, used for borders
    'bar':       '#F9F9F9',   # nav / tab bar
    # text
    'label':     '#000000',
    'label2':    'rgba(60,60,67,0.60)',    # secondaryLabel
    'label3':    'rgba(60,60,67,0.30)',    # tertiaryLabel
    'label4':    'rgba(60,60,67,0.18)',    # quaternaryLabel
    # accents
    'blue':      '#007AFF',   # systemBlue   - temperature, the primary action
    'green':     '#34C759',   # systemGreen  - PWM / OK / START
    'red':       '#FF3B30',   # systemRed    - STOP / alarms
    'orange':    '#FF9500',   # systemOrange - setpoint / heating
    'yellow':    '#FFCC00',
    'teal':      '#30B0C7',   # systemTeal   - rate
    'cyan':      '#32ADE6',   # systemCyan   - cooling
    'purple':    '#AF52DE',   # systemPurple - calibration / profiles
    'pink':      '#FF2D55',
    'grey':      '#8E8E93',   # systemGray
    'grey4':     '#D1D1D6',   # systemGray4  - switch off-track
    # chart
    'grid':      'rgba(60,60,67,0.12)',
    'shadow':    'rgba(0,0,0,0.06)',
}

DARK = {
    'bg':        '#000000',   # systemGroupedBackground (dark)
    'card':      '#1C1C1E',   # secondarySystemGroupedBackground (dark)
    'card2':     '#2C2C2E',
    'fill':      'rgba(120,120,128,0.36)',
    'sep':       '#38383A',
    'sep2':      '#38383A',
    'bar':       '#1C1C1E',
    'label':     '#FFFFFF',
    'label2':    'rgba(235,235,245,0.60)',
    'label3':    'rgba(235,235,245,0.30)',
    'label4':    'rgba(235,235,245,0.18)',
    'blue':      '#0A84FF',
    'green':     '#30D158',
    'red':       '#FF453A',
    'orange':    '#FF9F0A',
    'yellow':    '#FFD60A',
    'teal':      '#40C8E0',
    'cyan':      '#64D2FF',
    'purple':    '#BF5AF2',
    'pink':      '#FF375F',
    'grey':      '#8E8E93',
    'grey4':     '#3A3A3C',
    'grid':      'rgba(235,235,245,0.14)',
    'shadow':    'rgba(0,0,0,0.40)',
}

# ── GEOMETRY ────────────────────────────────────────────────────────────
# Apple does not use one radius everywhere: the continuous corner scales with
# the element. These are the three sizes the app needs.
R_CARD  = 16    # grouped card / chart panel
R_CTRL  = 12    # buttons, fields, segmented control
R_PILL  = 999   # capsule (status chip, switch)

PAD     = 14    # page gutter - iOS uses 16 at phone width, 14 reads better here
ROW_H   = 44    # iOS standard list row height
BAR_H   = 56    # tab bar

# ── TYPOGRAPHY ──────────────────────────────────────────────────────────
# SF Pro is NOT redistributable: Apple licenses it for interface work on Apple
# platforms only, and it is not installed on Windows. Inter is the standard
# stand-in - same grotesque skeleton, same closed apertures, open licence - and
# is shipped with the app in assets/. The fallbacks matter: on macOS the real
# system font IS SF Pro, so we let it through first there.
FONT_STACK = ['Inter', 'SF Pro Display', '.AppleSystemUIFont',
              'Segoe UI Variable Display', 'Segoe UI', 'DejaVu Sans']

# Apple's text styles, in points at 1x. The app scales these by a user factor.
TEXT = {
    'largeTitle': (34, 700),
    'title1':     (28, 700),
    'title2':     (22, 700),
    'title3':     (20, 600),
    'headline':   (17, 600),
    'body':       (17, 400),
    'callout':    (16, 400),
    'subhead':    (15, 400),
    'footnote':   (13, 400),
    'caption':    (12, 400),
    'caption2':   (11, 400),
}


class Theme:
    """The live appearance. One instance, shared; `mode` flips light/dark."""

    def __init__(self, mode: str = 'light', scale: float = 1.0):
        self.mode = mode
        self.scale = scale

    # -- colour access ---------------------------------------------------
    @property
    def p(self) -> dict:
        return DARK if self.mode == 'dark' else LIGHT

    def __getitem__(self, key: str) -> str:
        return self.p[key]

    @property
    def dark(self) -> bool:
        return self.mode == 'dark'

    def mpl(self, key: str) -> str:
        """The same colour for matplotlib, which wants #RRGGBB[AA], not rgba()."""
        v = self.p[key]
        if not v.startswith('rgba'):
            return v
        nums = v[v.index('(') + 1:v.index(')')].split(',')
        r, g, b = (int(float(x)) for x in nums[:3])
        a = int(round(float(nums[3]) * 255))
        return f'#{r:02X}{g:02X}{b:02X}{a:02X}'

    def solid(self, key: str, over: str = 'card') -> str:
        """A translucent colour flattened onto an opaque one.

        Needed wherever Qt will not composite for us - matplotlib figure text,
        for instance, is drawn onto the figure patch, not onto the card.
        """
        v = self.p[key]
        if not v.startswith('rgba'):
            return v
        nums = v[v.index('(') + 1:v.index(')')].split(',')
        r, g, b = (float(x) for x in nums[:3])
        a = float(nums[3])
        bg = self.p[over].lstrip('#')
        br, bgc, bb = (int(bg[i:i + 2], 16) for i in (0, 2, 4))
        return '#%02X%02X%02X' % (round(r * a + br * (1 - a)),
                                  round(g * a + bgc * (1 - a)),
                                  round(b * a + bb * (1 - a)))

    # -- type ------------------------------------------------------------
    def pt(self, style: str) -> int:
        """Point size for one of Apple's text styles, at the current scale."""
        return max(7, round(TEXT[style][0] * self.scale))

    def weight(self, style: str) -> int:
        return TEXT[style][1]

    def px(self, n: float) -> int:
        """Scale a pixel dimension the same way the text scales."""
        return max(1, round(n * self.scale))

    # -- the stylesheet --------------------------------------------------
    def qss(self) -> str:
        """The application stylesheet.

        Everything that can be expressed declaratively is expressed here, so
        that the Python widget code stays about behaviour. The custom-painted
        widgets (the switch, the tab bar, the chart) read the palette directly
        instead - a stylesheet cannot draw an animated knob.
        """
        c = self.p
        fam = ', '.join(f'"{f}"' for f in FONT_STACK)
        s = self.scale
        return f"""
* {{
    font-family: {fam};
    font-size: {self.pt('body')}pt;
    color: {c['label']};
    outline: none;
}}
QWidget#page       {{ background: {c['bg']}; }}
QWidget#bg         {{ background: {c['bg']}; }}
QScrollArea        {{ background: transparent; border: none; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}

/* ── the grouped card: iOS's white-on-grey list block ─────────────── */
QFrame#card {{
    background: {c['card']};
    border-radius: {round(R_CARD * s)}px;
    border: none;
}}
QFrame#card2 {{
    background: {c['card2']};
    border-radius: {round(R_CTRL * s)}px;
}}

/* ── section header above a group: small, upper, tertiary ─────────── */
QLabel#groupHeader {{
    color: {c['label2']};
    font-size: {self.pt('footnote')}pt;
    font-weight: 400;
    padding: 0px {round(PAD * s)}px {round(6 * s)}px {round(4 * s)}px;
}}
QLabel#groupFooter {{
    color: {c['label3']};
    font-size: {self.pt('caption')}pt;
    padding: {round(6 * s)}px {round(4 * s)}px 0px {round(4 * s)}px;
}}

/* ── list row ─────────────────────────────────────────────────────── */
QLabel#rowTitle    {{ font-size: {self.pt('body')}pt; color: {c['label']}; }}
QLabel#rowSub      {{ font-size: {self.pt('caption')}pt; color: {c['label2']}; }}
QLabel#rowValue    {{ font-size: {self.pt('body')}pt; color: {c['label2']}; }}
QFrame#sep         {{ background: {c['sep']}; border: none; max-height: 1px;
                      min-height: 1px; }}

/* ── stat tile ────────────────────────────────────────────────────── */
QLabel#statTitle   {{ font-size: {self.pt('caption')}pt; color: {c['label2']};
                      letter-spacing: {0.5 * s:.1f}px; }}
QLabel#statUnit    {{ font-size: {self.pt('footnote')}pt; color: {c['label3']}; }}

/* ── buttons: filled, tinted and plain, all capsule-ish ───────────── */
QPushButton {{
    background: {c['card']};
    color: {c['blue']};
    border: none;
    border-radius: {round(R_CTRL * s)}px;
    padding: {round(11 * s)}px {round(18 * s)}px;
    font-size: {self.pt('headline')}pt;
    font-weight: 600;
}}
QPushButton:hover    {{ background: {c['card2']}; }}
QPushButton:pressed  {{ color: {c['label3']}; }}
QPushButton:disabled {{ color: {c['label3']}; }}

QPushButton[kind="filled"] {{
    background: {c['blue']}; color: #FFFFFF;
}}
QPushButton[kind="filled"]:hover    {{ background: {c['blue']}; }}
QPushButton[kind="filled"]:pressed  {{ background: {c['blue']}; color: #FFFFFFB0; }}
QPushButton[kind="filled"]:disabled {{ background: {c['grey4']}; color: {c['label3']}; }}

QPushButton[kind="go"]   {{ background: {c['green']}; color: #FFFFFF; }}
QPushButton[kind="stop"] {{ background: {c['red']};   color: #FFFFFF; }}
QPushButton[kind="warn"] {{ background: {c['orange']};color: #FFFFFF; }}

QPushButton[kind="tinted"] {{
    background: {c['fill']}; color: {c['blue']};
}}
QPushButton[kind="plain"] {{
    background: transparent; color: {c['blue']};
    padding: {round(6 * s)}px {round(8 * s)}px;
}}
QPushButton[kind="destructive"] {{ background: transparent; color: {c['red']}; }}
QPushButton[kind="icon"] {{
    background: transparent; padding: {round(6 * s)}px;
    border-radius: {round(R_CTRL * s)}px;
}}
QPushButton[kind="icon"]:hover {{ background: {c['fill']}; }}

/* ── text fields ──────────────────────────────────────────────────── */
QLineEdit, QSpinBox, QDoubleSpinBox, QPlainTextEdit, QTextEdit {{
    background: {c['fill']};
    border: none;
    border-radius: {round(R_CTRL * s)}px;
    padding: {round(8 * s)}px {round(10 * s)}px;
    selection-background-color: {c['blue']};
    selection-color: #FFFFFF;
}}
QLineEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus {{
    background: {c['card2'] if self.dark else '#FFFFFF'};
    border: {max(1, round(2 * s))}px solid {c['blue']};
    padding: {round(8 * s) - max(1, round(2 * s))}px
             {round(10 * s) - max(1, round(2 * s))}px;
}}
QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{ width: 0px; border: none; }}

/* ── combo box: looks like an iOS menu button ─────────────────────── */
QComboBox {{
    background: {c['fill']};
    border: none;
    border-radius: {round(R_CTRL * s)}px;
    padding: {round(8 * s)}px {round(10 * s)}px;
    color: {c['label']};
}}
QComboBox::drop-down {{ border: none; width: {round(22 * s)}px; }}
QComboBox QAbstractItemView {{
    background: {c['card']};
    border: 1px solid {c['sep']};
    border-radius: {round(R_CTRL * s)}px;
    padding: {round(4 * s)}px;
    selection-background-color: {c['blue']};
    selection-color: #FFFFFF;
    outline: none;
}}

/* ── list / table ─────────────────────────────────────────────────── */
QListWidget, QTreeWidget, QTableWidget {{
    background: transparent;
    border: none;
    outline: none;
    /* the rows are rounded, so they need room inside the card or the
       selection paints right into the card's own corner */
    padding: {round(6 * s)}px;
}}
QListWidget::item, QTreeWidget::item {{
    padding: {round(7 * s)}px {round(8 * s)}px;
    border-radius: {round(8 * s)}px;
    color: {c['label']};
}}
QListWidget::item:selected, QTreeWidget::item:selected {{
    background: {c['blue']}; color: #FFFFFF;
}}

/* ── the iOS multi-select tick: a ring that fills in blue ─────────── */
QListWidget::indicator {{
    width: {round(18 * s)}px; height: {round(18 * s)}px;
    border-radius: {round(9 * s)}px;
    border: {max(1, round(1.6 * s))}px solid {c['label3']};
    background: transparent;
}}
QListWidget::indicator:checked {{
    background: {c['blue']}; border-color: {c['blue']};
}}

QHeaderView::section {{
    background: transparent;
    color: {c['label2']};
    border: none;
    border-bottom: 1px solid {c['sep']};
    padding: {round(6 * s)}px {round(4 * s)}px;
    font-size: {self.pt('caption')}pt;
}}

/* ── scrollbar: the thin iOS overlay indicator ────────────────────── */
QScrollBar:vertical {{
    background: transparent; width: {round(8 * s)}px; margin: 0px;
}}
QScrollBar::handle:vertical {{
    background: {c['label3']};
    border-radius: {round(4 * s)}px; min-height: {round(30 * s)}px;
}}
QScrollBar::handle:vertical:hover {{ background: {c['label2']}; }}
QScrollBar::add-line, QScrollBar::sub-line,
QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none;
                                              height: 0px; width: 0px; }}
QScrollBar:horizontal {{ background: transparent; height: {round(8 * s)}px; }}
QScrollBar::handle:horizontal {{
    background: {c['label3']}; border-radius: {round(4 * s)}px;
    min-width: {round(30 * s)}px;
}}

/* ── slider: iOS track + big round knob ───────────────────────────── */
QSlider::groove:horizontal {{
    background: {c['grey4']}; height: {round(4 * s)}px;
    border-radius: {round(2 * s)}px;
}}
QSlider::sub-page:horizontal {{
    background: {c['blue']}; height: {round(4 * s)}px;
    border-radius: {round(2 * s)}px;
}}
QSlider::handle:horizontal {{
    background: #FFFFFF;
    border: 1px solid rgba(0,0,0,0.04);
    width: {round(22 * s)}px; height: {round(22 * s)}px;
    margin: -{round(9 * s)}px 0px;
    border-radius: {round(11 * s)}px;
}}
QSlider::handle:horizontal:disabled {{ background: {c['grey4']}; }}

/* ── progress ─────────────────────────────────────────────────────── */
QProgressBar {{
    background: {c['grey4']}; border: none;
    border-radius: {round(2 * s)}px; height: {round(4 * s)}px;
    text-align: center; color: transparent;
}}
QProgressBar::chunk {{ background: {c['blue']}; border-radius: {round(2 * s)}px; }}

/* ── tooltip: the iOS dark capsule ────────────────────────────────── */
QToolTip {{
    background: {'#3A3A3C' if not self.dark else '#F2F2F7'};
    color: {'#FFFFFF' if not self.dark else '#000000'};
    border: none; border-radius: {round(8 * s)}px;
    padding: {round(6 * s)}px {round(9 * s)}px;
    font-size: {self.pt('footnote')}pt;
}}

/* ── dialogs and message boxes ────────────────────────────────────── */
QDialog, QMessageBox {{ background: {c['bg']}; }}
QMenu {{
    background: {c['card']}; border: 1px solid {c['sep']};
    border-radius: {round(R_CTRL * s)}px; padding: {round(4 * s)}px;
}}
QMenu::item {{ padding: {round(7 * s)}px {round(14 * s)}px;
               border-radius: {round(7 * s)}px; }}
QMenu::item:selected {{ background: {c['blue']}; color: #FFFFFF; }}
QCheckBox::indicator, QRadioButton::indicator {{
    width: {round(20 * s)}px; height: {round(20 * s)}px;
}}
"""
