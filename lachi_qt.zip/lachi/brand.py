#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - the wordmark and the emblem, as geometry.

Carried over unchanged from the Tkinter build. The letters are NOT a font:
they are polygons in a cap-height space, drawn from the same vocabulary as the
emblem, so the mark reads as one designed object rather than a picture standing
next to some text in whatever font the machine happens to have.

WHAT CHANGED IN THE PORT: nothing in the geometry - every coordinate, the
solved A, the kerning table and the emblem spline are exactly as designed. Only
the renderer is new. Tk's canvas has no anti-aliasing, so the Tkinter build
drew the mark into a PIL image at 4x and downsampled it with LANCZOS. QPainter
anti-aliases natively and works in floating-point coordinates, so the
supersampling scaffolding is gone and the letterforms are resolution
independent - they are as sharp at 200 px as at 17.
"""
from __future__ import annotations

import math

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import QColor, QPainter, QPainterPath, QPen, QPixmap

APP_NAME = "LACHI"


# ── helpers ─────────────────────────────────────────────────────────────
def lighten(hex_color: str, amount: float = 0.15) -> str:
    c = QColor(hex_color)
    return QColor(
        min(255, round(c.red() + (255 - c.red()) * amount)),
        min(255, round(c.green() + (255 - c.green()) * amount)),
        min(255, round(c.blue() + (255 - c.blue()) * amount))).name()


def darken(hex_color: str, amount: float = 0.30) -> str:
    c = QColor(hex_color)
    return QColor(round(c.red() * (1 - amount)),
                  round(c.green() * (1 - amount)),
                  round(c.blue() * (1 - amount))).name()


# ════════════════════════════════════════════════════════════════════════
#  WORDMARK
# ════════════════════════════════════════════════════════════════════════
# Coordinates: x to the right, y UP, baseline at y=0, cap height y=1. Each
# entry is (advance_width, [polygons]). _W is the stroke weight, _K the chamfer
# that keeps the corners from looking machined.
_W = 0.26          # stroke weight - ONE weight for every stroke in the set
_K = 0.075         # corner chamfer

# ── THE A, AND WHY IT NEEDS ITS OWN ARITHMETIC ─────────────────────────
# A slanted stroke of a given HORIZONTAL width is thinner measured across
# itself, so matching the A to its slab-sided neighbours needs
#     _AW = _W * sqrt(1 + R^2),  R = horizontal run per unit height.
# And for the legs to be TRUE parallelograms (equal width along their whole
# length, not just at one height) the apex width must EQUAL the leg's
# horizontal extent - top and bottom edges of a parallelogram are the same.
# That makes the apex a solved quantity rather than a chosen one:
#     _AW = _W * sqrt(1 + R^2),   R = (A - _AW) / 2,   apex = _AW
# Two unknowns, two equations, fixed point converges in a handful of steps.
_A_ADV, _A_BAR = 1.30, 0.17                 # width, crossbar height


def _solve_leg(adv: float, w: float) -> float:
    aw = w
    for _ in range(40):
        r = (adv - aw) / 2.0
        nw = w * math.sqrt(1.0 + r * r)
        if abs(nw - aw) < 1e-12:
            break
        aw = nw
    return aw


_AW = _solve_leg(_A_ADV, _W)                # leg extent ...
_A_APEX = _AW                               # ... and the apex, necessarily equal
_A_CTR = _A_ADV / 2.0


def _a_inner(y: float, left: bool = True) -> float:
    """x of a leg's INNER edge at height y (0 = baseline, 1 = cap)."""
    x0 = _AW if left else _A_ADV - _AW
    x1 = _A_CTR + (_A_APEX / 2 if left else -_A_APEX / 2)
    return x0 + y * (x1 - x0)


GLYPHS = {
    # L - stem plus foot, chamfered at the outer bottom corner
    'L': (0.68, [[(0, 1), (_W, 1), (_W, _W), (0.68, _W), (0.68 - _K, 0), (0, 0)]]),
    # A - two splayed legs meeting at a flat apex, plus a fitted crossbar
    'A': (_A_ADV, [
        [(0, 0), (_AW, 0), (_A_CTR + _A_APEX / 2, 1), (_A_CTR - _A_APEX / 2, 1)],
        [(_A_ADV, 0), (_A_ADV - _AW, 0), (_A_CTR - _A_APEX / 2, 1),
         (_A_CTR + _A_APEX / 2, 1)],
        [(_a_inner(_A_BAR, True), _A_BAR),
         (_a_inner(_A_BAR, False), _A_BAR),
         (_a_inner(_A_BAR + _W, False), _A_BAR + _W),
         (_a_inner(_A_BAR + _W, True), _A_BAR + _W)],
    ]),
    # C - an angular ring, opened on the right by exactly one stroke width so
    # it cannot be read as a bracket
    'C': (0.78, [[(0.78, 1), (0.20, 1), (0, 1 - 0.22), (0, 0.22), (0.20, 0),
                  (0.78, 0), (0.78, _W), (0.26, _W), (_W, _W + 0.13),
                  (_W, 1 - _W - 0.13), (0.26, 1 - _W), (0.78, 1 - _W)]]),
    # H - two stems and a waist bar
    'H': (0.84, [
        [(0, 1), (_W, 1), (_W, 0), (0, 0)],
        [(0.84 - _W, 1), (0.84, 1), (0.84, 0), (0.84 - _W, 0)],
        [(_W, 0.50 + _W / 2), (0.84 - _W, 0.50 + _W / 2),
         (0.84 - _W, 0.50 - _W / 2), (_W, 0.50 - _W / 2)],
    ]),
    # I - stem with slab serifs, so it cannot be mistaken for a divider
    'I': (0.56, [
        [(0, 1), (0.56, 1), (0.56, 1 - _W), (0, 1 - _W)],
        [(0, _W), (0.56, _W), (0.56, 0), (0, 0)],
        [(0.28 - _W / 2, 1 - _W), (0.28 + _W / 2, 1 - _W),
         (0.28 + _W / 2, _W), (0.28 - _W / 2, _W)],
    ]),
}

TRACKING = 0.20    # base gap between letter BOXES, in cap-height units

# TRACKING alone spaces the bounding BOXES, and boxes are a poor model of what
# the eye sees. Measured on the rasterised letters the white between pairs came
# out LA 0.773, AC 0.497, CH 0.449, HI 0.272 - LA nearly three times looser
# than HI. In an alphabet that is four parallel-sided letters plus one A what
# the eye judges is the NEAREST APPROACH, so these kerns equalise that: every
# pair now comes within exactly TRACKING of its neighbour at its closest point.
KERN = {
    'LA': -0.075,   # L's arm is empty above the foot; A meets it at the baseline
    'AC': -0.112,   # A's right leg leans away from C's flat left side
}


def wordmark_width(text: str = APP_NAME, h: float = 1.0) -> float:
    """Total width at cap height h - needed to reserve space before drawing."""
    adv = sum(GLYPHS[c][0] for c in text if c in GLYPHS)
    n = len([c for c in text if c in GLYPHS])
    kern = sum(KERN.get(text[i:i + 2], 0.0) for i in range(len(text) - 1))
    return (adv + TRACKING * max(0, n - 1) + kern) * h


def wordmark_path(x: float, y: float, h: float, text: str = APP_NAME) -> QPainterPath:
    """The wordmark as one path, with (x, y) at the BASELINE LEFT.

    y grows DOWN in Qt, exactly as it did in Tk, so the glyph's y is subtracted.
    """
    p = QPainterPath()
    p.setFillRule(Qt.FillRule.WindingFill)
    cx = x
    prev = None
    for ch in text:
        if prev is not None:
            cx += KERN.get(prev + ch, 0.0) * h
        prev = ch
        g = GLYPHS.get(ch)
        if not g:
            cx += 0.4 * h
            continue
        adv, polys = g
        for poly in polys:
            sub = QPainterPath()
            for i, (px, py) in enumerate(poly):
                pt = QPointF(cx + px * h, y - py * h)
                sub.moveTo(pt) if i == 0 else sub.lineTo(pt)
            sub.closeSubpath()
            p.addPath(sub)
        cx += (adv + TRACKING) * h
    return p


def draw_wordmark(q: QPainter, x: float, y: float, h: float, color: str,
                  text: str = APP_NAME, chisel: bool = True):
    """Paint the wordmark at baseline-left (x, y).

    The chiselled look comes from three passes rather than per-stroke facet
    geometry: a dark copy pushed down-right, a light copy pulled up-left, then
    the solid letters on top. Cheap, and it cannot get out of step with the
    outline the way hand-placed facets would. `chisel=False` gives the flat
    single-colour mark, which is what the iOS header uses - a bevel would be
    out of place next to Cupertino's flat surfaces.
    """
    q.setPen(Qt.PenStyle.NoPen)
    passes = [(0.0, 0.0, color)]
    if chisel:
        d = h * 0.028
        passes = [(d, d, darken(color, 0.45)),
                  (-d * 0.6, -d * 0.6, lighten(color, 0.55)),
                  (0.0, 0.0, color)]
    for dx, dy, col in passes:
        q.setBrush(QColor(col))
        q.drawPath(wordmark_path(x + dx, y + dy, h, text))


def wordmark_pixmap(h: int, color: str, text: str = APP_NAME,
                    dpr: float = 2.0, chisel: bool = False) -> QPixmap:
    """The wordmark as a pixmap of cap height `h`, transparent background."""
    w = int(math.ceil(wordmark_width(text, h))) + 2
    ht = h + 2
    px = QPixmap(int(w * dpr), int(ht * dpr))
    px.setDevicePixelRatio(dpr)
    px.fill(Qt.GlobalColor.transparent)
    q = QPainter(px)
    q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    draw_wordmark(q, 1, h + 1, h, color, text, chisel)
    q.end()
    return px


# ════════════════════════════════════════════════════════════════════════
#  EMBLEM
# ════════════════════════════════════════════════════════════════════════
# An ORIGINAL heraldic beast-head mark, defined once as polygons in a -1..1
# space with y pointing UP. Nothing is traced from anyone else's artwork.
#
# Deliberately NOT a redrawn Witcher medallion: redrawing a protected logo
# produces a derivative work, which is still protected, and that particular
# head is a trademark on top of that. What is not protectable is the genre
# vocabulary - an angular animal head, faceted planes, gold on near-black - so
# the vocabulary is borrowed and the drawing is our own: a closed, calm,
# symmetrical head instead of a snarling one, swept horns instead of a spiked
# halo, a plain ring instead of a fanned crest, and no row of sign glyphs
# underneath (that row is the part that makes their composition theirs).
EMBLEM_SOLID = [[
    (-0.54, 1.10), (-0.34, 0.66), (-0.13, 0.70), (0.13, 0.70), (0.34, 0.66),
    ( 0.58, 1.12), ( 0.74, 0.54), ( 0.88, 0.18), (1.02, -0.12), (0.68, -0.22),
    ( 0.88, -0.54), ( 0.46, -0.44), (0.42, -0.66), (0.27, -0.56),
    ( 0.24, -0.84), ( 0.00, -0.96), (-0.24, -0.84), (-0.27, -0.56),
    (-0.40, -0.68), (-0.46, -0.44), (-0.84, -0.58), (-0.70, -0.22),
    (-1.02, -0.12), (-0.86, 0.18), (-0.72, 0.52),
]]
# The planes the light falls on. One convention: the light comes from the upper
# LEFT, so left-facing planes are lit and right-facing ones are in shadow, with
# a bright ridge down the centre of the face. Drawn WITHOUT spline smoothing on
# purpose - hard facet edges are what makes it look chiselled rather than
# moulded - and deliberately coarse, because this also has to survive being
# 20 px wide in a header.
EMBLEM_LIT = [
    [(-0.54, 1.06), (-0.34, 0.66), (-0.15, 0.73), (-0.31, 0.92)],
    [(-0.34, 0.66), (-0.13, 0.70), (0.00, 0.22), (-0.22, -0.04),
     (-0.64, 0.14), (-0.72, 0.46)],
    [(-1.00, -0.12), (-0.66, -0.20), (-0.50, -0.42), (-0.84, -0.56)],
    [(-0.22, -0.04), (0.00, 0.04), (0.00, -0.90), (-0.17, -0.78), (-0.27, -0.52)],
]
EMBLEM_SHADE = [
    [( 0.58, 1.08), ( 0.34, 0.66), ( 0.15, 0.73), ( 0.33, 0.92)],
    [( 0.34, 0.66), ( 0.13, 0.70), (0.00, 0.22), (0.22, -0.04),
     ( 0.64, 0.14), ( 0.74, 0.46)],
    [( 1.00, -0.12), ( 0.66, -0.20), (0.50, -0.42), (0.86, -0.54)],
    [( 0.22, -0.04), ( 0.00, 0.04), (0.00, -0.90), (0.18, -0.78), (0.27, -0.52)],
]
EMBLEM_RIDGE = [
    [(-0.052, 0.52), (0.052, 0.52), (0.028, -0.50), (0.0, -0.60), (-0.028, -0.50)],
]
# Only the eyes are punched back out. Every extra cut is one more thing that
# reads as a seam on a mask, and at small sizes one more thing that turns to mud.
EMBLEM_VOID = [
    [(-0.60, 0.30), (-0.34, 0.16), (-0.20, 0.00), (-0.34, -0.04), (-0.56, 0.10)],
    [( 0.60, 0.30), ( 0.34, 0.16), ( 0.20, 0.00), ( 0.34, -0.04), ( 0.56, 0.10)],
]


def _spline(pts, steps: int = 10):
    """Closed Catmull-Rom through pts - the curve passes through every control
    point, so the ear and tuft tips stay sharp while everything between them
    curves.

    WHY A SPLINE AND NOT A POLYGON: two earlier attempts drew straight-edged
    polygons. The first came out as a rat (needle snout, swept-back ears); the
    second, once the facets were tidied, came out as a Transformers faceplate -
    because hard straight edges meeting at machined angles is exactly what a
    robot mask is. Fur and bone are curved.
    """
    n = len(pts)
    out = []
    for i in range(n):
        p0 = pts[(i - 1) % n]; p1 = pts[i]
        p2 = pts[(i + 1) % n]; p3 = pts[(i + 2) % n]
        for j in range(steps):
            t = j / steps
            t2 = t * t; t3 = t2 * t
            out.append((
                0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t +
                       (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
                       (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
                0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t +
                       (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
                       (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)))
    return out


def _poly_path(poly, cx, cy, k) -> QPainterPath:
    p = QPainterPath()
    for i, (x, y) in enumerate(poly):
        pt = QPointF(cx + x * k, cy - y * k)     # minus: Qt y grows downward
        p.moveTo(pt) if i == 0 else p.lineTo(pt)
    p.closeSubpath()
    return p


def draw_medallion(q: QPainter, cx: float, cy: float, r: float, color: str,
                   bg: str, ring: bool = True):
    """The emblem, centred at (cx, cy) with radius r. Purely decorative -
    nothing in the control path depends on it."""
    q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    if ring:
        pen = QPen(QColor(color), max(1.0, r * 0.12))
        q.setPen(pen)
        q.setBrush(Qt.BrushStyle.NoBrush)
        q.drawEllipse(QRectF(cx - r, cy - r, 2 * r, 2 * r))
    q.setPen(Qt.PenStyle.NoPen)
    k = r * 0.62
    for polys, col in ((EMBLEM_SOLID, color),
                       (EMBLEM_SHADE, darken(color, 0.34)),
                       (EMBLEM_LIT, lighten(color, 0.42)),
                       (EMBLEM_RIDGE, lighten(color, 0.62))):
        for poly in polys:
            pts = _spline(poly) if polys is EMBLEM_SOLID else poly
            q.setBrush(QColor(col))
            q.drawPath(_poly_path(pts, cx, cy, k))
    # The eyes are cut back out. On a transparent pixmap that means clearing
    # the pixels rather than painting the background over them, or the mark
    # would carry two opaque patches wherever it is placed.
    if bg == 'transparent':
        q.setCompositionMode(QPainter.CompositionMode.CompositionMode_Clear)
        q.setBrush(QColor(0, 0, 0, 255))
    else:
        q.setBrush(QColor(bg))
    for poly in EMBLEM_VOID:
        q.drawPath(_poly_path(_spline(poly, 6), cx, cy, k))
    q.setCompositionMode(QPainter.CompositionMode.CompositionMode_SourceOver)


def medallion_pixmap(size: int, color: str, bg: str, dpr: float = 2.0) -> QPixmap:
    px = QPixmap(int(size * dpr), int(size * dpr))
    px.setDevicePixelRatio(dpr)
    px.fill(Qt.GlobalColor.transparent)
    q = QPainter(px)
    draw_medallion(q, size / 2, size / 2, size / 2 - 1, color, bg)
    q.end()
    return px
