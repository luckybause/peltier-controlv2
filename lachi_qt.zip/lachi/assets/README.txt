Optional fonts.

Every .ttf or .otf dropped in this folder is loaded at startup and becomes
available to the stylesheet. The app asks for Inter first; when it is not
here, the font stack in lachi/theme.py falls through to whatever the platform
uses for its own interface — Segoe UI Variable on Windows 11, SF Pro on macOS,
the system UI font on Linux. Everything lays out the same either way, so this
folder can stay empty.

Inter is free (SIL Open Font License 1.1) and can be downloaded from
https://rsms.me/inter/ — the files to copy here are Inter-Regular.ttf,
Inter-Medium.ttf, Inter-SemiBold.ttf and Inter-Bold.ttf.

The LACHI wordmark and the emblem are NOT typed in a font; they are drawn as
geometry in lachi/brand.py, so they look identical on every machine whether or
not anything is in this folder.
