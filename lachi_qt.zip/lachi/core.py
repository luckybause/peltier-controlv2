#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - constants, protocol decoding and the small helpers the UI leans on.

Everything here is framework-agnostic instrument logic carried over from the
Tkinter build, plus the handful of Qt conveniences (message boxes, file
dialogs) that let the ported code read the way the original did.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from PyQt6.QtWidgets import QFileDialog, QInputDialog, QLineEdit, QMessageBox

# Version of the PC APPLICATION. Not to be confused with FW - the firmware
# build the app reads from the board with VER and shows separately.
APP_NAME = "LACHI"
APP_BUILD = "2026-09-22.qt1"

# Safety limits for the automatic MEASUREMENT SERIES - a safeguard in case an
# approach or return never reaches its target (a disconnected sensor, say):
# the series should move on rather than hang forever.
SERIES_HEAT_TIMEOUT_S = 20 * 60
SERIES_COOL_TIMEOUT_S = 12 * 60

# ── "REACHED" CRITERION ─────────────────────────────────────────────────
# Was: a single sample within 0.5 C and done. For the DESCENT leg in a series
# (which ends immediately after reaching) that meant EVERY descent was cut off
# the moment it entered tolerance - the logs contained not a single hold
# sample, which made it impossible to check whether the descent actually gets
# to its target and whether it crosses it. That was exactly what we were
# trying to diagnose.
# Now: |error| <= REACH_TOL_C held CONTINUOUSLY for REACH_STABLE_S, so a single
# brush against the tolerance caused by noise is no longer enough.
REACH_TOL_C = 0.2
REACH_STABLE_S = 3.0

# ── PC SIDE OF THE SLEEP GUARD ──────────────────────────────────────────
# tick() runs every ~250 ms. If the wall clock jumps by much more than that,
# this process was NOT running - the machine slept, hibernated or froze, and a
# measurement was no longer being supervised or logged. The safe response is to
# end the run, not to carry on with a hole in the data.
STALL_LIMIT_S = 6.0
PING_EVERY_S = 1.0

# ── FIRMWARE ERROR CODES (ERR:code=N,...,active=0/1) ────────────────────
ERR_CODES = {
    1: "Main thermocouple fault",
    2: "Thermocouple reading out of range / noise",
    3: "TEMP MAX - safe shutdown",
    4: "MAX31856 not responding (SPI/connection)",
}
# MAX31856 fault register bitmask (Adafruit_MAX31856.h)
TC_FAULT_BITS = [
    (0x80, "cold junction range (CJ range)"),
    (0x40, "thermocouple range (TC range)"),
    (0x20, "cold junction too high (CJ high)"),
    (0x10, "cold junction too low (CJ low)"),
    (0x08, "thermocouple too hot (TC high)"),
    (0x04, "thermocouple too cold (TC low)"),
    (0x02, "overvoltage/undervoltage (OV/UV)"),
    (0x01, "open circuit - wire broken/disconnected"),
]


def decode_tc_fault(bits: int) -> str:
    names = [name for mask, name in TC_FAULT_BITS if bits & mask]
    return ", ".join(names) if names else f"bitmask 0x{bits:02X}"


# ── CSV COLUMN NAMES: ENGLISH NOW, POLISH STILL READABLE ────────────────
# The measurement CSV used to have Polish headers. New files are written with
# English ones, but every file already in the data folder has the old names and
# the ARCHIVE tab must keep opening them. So the writer emits CSV_COLS and the
# reader passes every row through csv_row(), which makes BOTH spellings
# resolve. No migration step, and no existing measurement becomes unreadable.
CSV_COLS = ['time_s', 'temperature_C', 'setpoint_active', 'setpoint_target',
            'PWM', 'PWM_%', 'Kp', 'Ki', 'Kd', 'state', 'temperature2_C',
            'ff', 'p_term', 'i_term', 'd_term', 'pid_raw', 'react_scale',
            'amb_est', 'pc_time']
CSV_ALIAS = {
    'czas_s':            'time_s',
    'temperatura_C':     'temperature_C',
    'setpoint_aktywny':  'setpoint_active',
    'setpoint_cel':      'setpoint_target',
    'stan':              'state',
    'temperatura2_C':    'temperature2_C',
    'czas_pc':           'pc_time',
}


def csv_row(r: dict) -> dict:
    """One CSV row readable under BOTH the old Polish and the new English
    column names. Cheap - a handful of dict writes per row - and it keeps the
    whole archive working without a migration."""
    for old, new in CSV_ALIAS.items():
        if old in r and new not in r:
            r[new] = r[old]
        elif new in r and old not in r:
            r[old] = r[new]
    return r


# ════════════════════════════════════════════════════════════════════════
#  A TK-SHAPED VARIABLE
# ════════════════════════════════════════════════════════════════════════
class Var:
    """get()/set() holder, so the ported instrument logic reads unchanged.

    The Tkinter build passed StringVar/BooleanVar around. Qt has no equivalent
    and does not need one - but rewriting every call site would have meant
    touching the series state machine and the archive filters, which are the
    two places where a silent behaviour change is hardest to notice. This keeps
    those call sites literally identical.
    """

    # Deliberately NOT __slots__: Qt takes a weak reference to any bound method
    # connected to a signal, and a slotted instance cannot be weak-referenced.

    def __init__(self, value=None, on_change=None):
        self._v = value
        self._cb = on_change

    def get(self):
        return self._v

    def set(self, value):
        changed = value != self._v
        self._v = value
        if changed and self._cb:
            self._cb(value)


# ════════════════════════════════════════════════════════════════════════
#  DIALOG HELPERS
# ════════════════════════════════════════════════════════════════════════
# iOS alerts are title + body + buttons, which is what QMessageBox is; these
# wrappers exist so the ported code keeps reading like messagebox.showwarning.
def _box(parent, icon, title, text) -> QMessageBox:
    m = QMessageBox(parent)
    m.setIcon(icon)
    m.setWindowTitle(title)
    m.setText(f"<b>{title}</b>")
    m.setInformativeText(text)
    return m


def info(parent, title, text):
    _box(parent, QMessageBox.Icon.Information, title, text).exec()


def warn(parent, title, text):
    _box(parent, QMessageBox.Icon.Warning, title, text).exec()


def error(parent, title, text):
    _box(parent, QMessageBox.Icon.Critical, title, text).exec()


def ask(parent, title, text) -> bool:
    m = _box(parent, QMessageBox.Icon.Question, title, text)
    m.setStandardButtons(QMessageBox.StandardButton.Yes |
                         QMessageBox.StandardButton.No)
    m.setDefaultButton(QMessageBox.StandardButton.No)
    return m.exec() == QMessageBox.StandardButton.Yes


def ask_text(parent, title, label, default="") -> str | None:
    txt, ok = QInputDialog.getText(parent, title, label, QLineEdit.EchoMode.Normal,
                                   default)
    return txt if ok else None


def save_path(parent, title, default_name, filters, directory=None) -> str | None:
    start = str(Path(directory) / default_name) if directory else default_name
    path, _ = QFileDialog.getSaveFileName(parent, title, start, filters)
    return path or None


def open_path(parent, title, filters, directory=None) -> str | None:
    path, _ = QFileDialog.getOpenFileName(parent, title,
                                          str(directory) if directory else "",
                                          filters)
    return path or None


def choose_dir(parent, title, directory=None) -> str | None:
    path = QFileDialog.getExistingDirectory(parent, title,
                                            str(directory) if directory else "")
    return path or None


def reveal(path):
    """Open a folder in the platform's file manager."""
    try:
        import subprocess
        p = str(path)
        if sys.platform == 'win32':
            os.startfile(p)                                   # noqa: S606
        elif sys.platform == 'darwin':
            subprocess.run(['open', p], check=False)
        else:
            subprocess.run(['xdg-open', p], check=False)
        return True
    except Exception:
        return False


def fmt_hms(seconds: float) -> str:
    """0:07 / 3m 12s - the two shapes the readouts use."""
    m = int(seconds // 60)
    s = int(seconds % 60)
    return f"{m}m {s}s" if m else f"{s}s"
