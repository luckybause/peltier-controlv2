#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
LACHI - an SF-Symbols-shaped icon set, drawn as vectors.

WHY DRAWN AND NOT A FONT
------------------------
SF Symbols is an Apple font under the same licence as SF Pro: it may be used
in interfaces on Apple platforms, and it is not on Windows. Rather than ship a
look-alike font of uncertain provenance, every glyph this app needs is drawn
here from primitives, on the same 24x24 grid and with the same construction
rules SF Symbols uses:

  * one stroke weight per glyph, round caps and round joins
  * geometry snapped to the grid, so shapes stay crisp when scaled
  * an optical size of 24, which is what iOS tab bars and rows use

They are painted straight into a QPixmap at device resolution, so they stay
sharp on a 4K panel and on a 96-DPI laptop alike.
"""
from __future__ import annotations

import math

from PyQt6.QtCore import QPointF, QRectF, Qt
from PyQt6.QtGui import (QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap,
                         QTransform)

G = 24.0          # the design grid every glyph is drawn on
_CACHE: dict = {}


# ── primitives ──────────────────────────────────────────────────────────
def _line(p: QPainterPath, x1, y1, x2, y2):
    p.moveTo(x1, y1)
    p.lineTo(x2, y2)


def _rr(p: QPainterPath, x, y, w, h, r):
    p.addRoundedRect(QRectF(x, y, w, h), r, r)


def _arc(p: QPainterPath, cx, cy, r, a0, a1):
    """Arc in degrees, counter-clockwise from 3 o'clock (Qt convention)."""
    rect = QRectF(cx - r, cy - r, 2 * r, 2 * r)
    p.arcMoveTo(rect, a0)
    p.arcTo(rect, a0, a1 - a0)


# ── the glyphs ──────────────────────────────────────────────────────────
# Each returns (stroke_path, fill_path). Either may be None.
def _gauge():
    """SF: gauge.medium - the dial with a needle. The CONTROL tab."""
    s = QPainterPath()
    s.addEllipse(QRectF(2.6, 2.6, 18.8, 18.8))
    f = QPainterPath()
    # tick marks at 8 compass points, short and fat, as SF draws them
    for a in range(0, 360, 45):
        t = math.radians(a)
        f.addEllipse(QPointF(12 + 7.0 * math.cos(t), 12 + 7.0 * math.sin(t)),
                     0.95, 0.95)
    # the needle: a tapered wedge pointing up-right, plus the hub
    n = QPainterPath()
    n.moveTo(12 - 1.05, 12 + 0.55)
    n.lineTo(12 + 1.05, 12 - 0.55)
    n.lineTo(16.9, 7.4)
    n.closeSubpath()
    f.addPath(n)
    f.addEllipse(QPointF(12, 12), 1.9, 1.9)
    return s, f


def _list_bullet():
    """SF: list.bullet - the SERIES tab."""
    s = QPainterPath()
    for y in (6.6, 12.0, 17.4):
        _line(s, 9.2, y, 20.2, y)
    f = QPainterPath()
    for y in (6.6, 12.0, 17.4):
        f.addEllipse(QPointF(4.7, y), 1.45, 1.45)
    return s, f


def _archivebox():
    """SF: archivebox - the ARCHIVE tab."""
    s = QPainterPath()
    _rr(s, 3.2, 3.4, 17.6, 4.4, 1.5)
    s.moveTo(4.8, 8.4)
    s.lineTo(4.8, 18.1)
    s.quadTo(4.8, 20.6, 7.3, 20.6)
    s.lineTo(16.7, 20.6)
    s.quadTo(19.2, 20.6, 19.2, 18.1)
    s.lineTo(19.2, 8.4)
    _line(s, 9.7, 12.4, 14.3, 12.4)
    return s, None


def _sliders():
    """SF: slider.horizontal.3 - the TUNING tab."""
    s = QPainterPath()
    rows = ((6.4, 8.9), (12.0, 15.1), (17.6, 10.6))
    for y, kx in rows:
        _line(s, 3.4, y, kx - 2.1, y)
        _line(s, kx + 2.1, y, 20.6, y)
    f = QPainterPath()
    for y, kx in rows:
        f.addEllipse(QPointF(kx, y), 2.05, 2.05)
    return s, f


def _gear():
    """SF: gearshape - the DEVICE tab. Eight teeth, as Apple draws it."""
    s = QPainterPath()
    ro, ri, teeth = 9.5, 7.4, 8
    path = QPainterPath()
    half = math.pi / teeth * 0.44
    for i in range(teeth):
        a = 2 * math.pi * i / teeth - math.pi / 2
        # outer tooth face
        p0 = (12 + ro * math.cos(a - half), 12 + ro * math.sin(a - half))
        p1 = (12 + ro * math.cos(a + half), 12 + ro * math.sin(a + half))
        b = a + math.pi / teeth
        q0 = (12 + ri * math.cos(b - half * 1.5), 12 + ri * math.sin(b - half * 1.5))
        q1 = (12 + ri * math.cos(b + half * 1.5), 12 + ri * math.sin(b + half * 1.5))
        if i == 0:
            path.moveTo(*p0)
        else:
            path.lineTo(*p0)
        path.lineTo(*p1)
        path.lineTo(*q0)
        path.lineTo(*q1)
    path.closeSubpath()
    s.addPath(path)
    s.addEllipse(QPointF(12, 12), 3.3, 3.3)
    return s, None


def _play():
    f = QPainterPath()
    f.moveTo(7.4, 4.9)
    f.lineTo(19.3, 11.55)
    f.quadTo(20.1, 12.0, 19.3, 12.45)
    f.lineTo(7.4, 19.1)
    f.quadTo(6.4, 19.6, 6.4, 18.5)
    f.lineTo(6.4, 5.5)
    f.quadTo(6.4, 4.4, 7.4, 4.9)
    return None, f


def _stop():
    f = QPainterPath()
    _rr(f, 5.6, 5.6, 12.8, 12.8, 2.6)
    return None, f


def _pause():
    f = QPainterPath()
    _rr(f, 6.2, 5.2, 4.0, 13.6, 1.6)
    _rr(f, 13.8, 5.2, 4.0, 13.6, 1.6)
    return None, f


def _xmark():
    s = QPainterPath()
    _line(s, 6.6, 6.6, 17.4, 17.4)
    _line(s, 17.4, 6.6, 6.6, 17.4)
    return s, None


def _checkmark():
    s = QPainterPath()
    s.moveTo(5.2, 12.6)
    s.lineTo(9.9, 17.2)
    s.lineTo(18.8, 6.8)
    return s, None


def _plus():
    s = QPainterPath()
    _line(s, 12, 5.2, 12, 18.8)
    _line(s, 5.2, 12, 18.8, 12)
    return s, None


def _minus():
    s = QPainterPath()
    _line(s, 5.2, 12, 18.8, 12)
    return s, None


def _trash():
    s = QPainterPath()
    _line(s, 3.6, 6.4, 20.4, 6.4)
    s.moveTo(5.9, 6.4)
    s.lineTo(6.7, 19.0)
    s.quadTo(6.85, 20.8, 8.6, 20.8)
    s.lineTo(15.4, 20.8)
    s.quadTo(17.15, 20.8, 17.3, 19.0)
    s.lineTo(18.1, 6.4)
    s.moveTo(9.1, 6.4)
    s.lineTo(9.1, 4.6)
    s.quadTo(9.1, 3.2, 10.5, 3.2)
    s.lineTo(13.5, 3.2)
    s.quadTo(14.9, 3.2, 14.9, 4.6)
    s.lineTo(14.9, 6.4)
    _line(s, 10.2, 9.6, 10.6, 17.6)
    _line(s, 13.8, 9.6, 13.4, 17.6)
    return s, None


def _square_arrow_down():
    """SF: square.and.arrow.down - export / save."""
    s = QPainterPath()
    s.moveTo(8.0, 9.4)
    s.lineTo(5.6, 9.4)
    s.quadTo(3.6, 9.4, 3.6, 11.4)
    s.lineTo(3.6, 18.6)
    s.quadTo(3.6, 20.6, 5.6, 20.6)
    s.lineTo(18.4, 20.6)
    s.quadTo(20.4, 20.6, 20.4, 18.6)
    s.lineTo(20.4, 11.4)
    s.quadTo(20.4, 9.4, 18.4, 9.4)
    s.lineTo(16.0, 9.4)
    _line(s, 12, 2.6, 12, 14.6)
    s.moveTo(8.3, 11.1)
    s.lineTo(12, 14.8)
    s.lineTo(15.7, 11.1)
    return s, None


def _square_arrow_up():
    """SF: square.and.arrow.up - share / export a chart."""
    s = QPainterPath()
    s.moveTo(8.0, 9.4)
    s.lineTo(5.6, 9.4)
    s.quadTo(3.6, 9.4, 3.6, 11.4)
    s.lineTo(3.6, 18.6)
    s.quadTo(3.6, 20.6, 5.6, 20.6)
    s.lineTo(18.4, 20.6)
    s.quadTo(20.4, 20.6, 20.4, 18.6)
    s.lineTo(20.4, 11.4)
    s.quadTo(20.4, 9.4, 18.4, 9.4)
    s.lineTo(16.0, 9.4)
    _line(s, 12, 15.0, 12, 3.0)
    s.moveTo(8.3, 6.5)
    s.lineTo(12, 2.8)
    s.lineTo(15.7, 6.5)
    return s, None


def _folder():
    s = QPainterPath()
    s.moveTo(3.4, 7.2)
    s.quadTo(3.4, 5.0, 5.6, 5.0)
    s.lineTo(9.3, 5.0)
    s.lineTo(11.3, 7.4)
    s.lineTo(18.4, 7.4)
    s.quadTo(20.6, 7.4, 20.6, 9.6)
    s.lineTo(20.6, 17.0)
    s.quadTo(20.6, 19.2, 18.4, 19.2)
    s.lineTo(5.6, 19.2)
    s.quadTo(3.4, 19.2, 3.4, 17.0)
    s.closeSubpath()
    return s, None


def _arrow_clockwise():
    s = QPainterPath()
    _arc(s, 12, 12, 8.0, 60, -250)
    f = QPainterPath()
    a = math.radians(-60)
    tip = QPointF(12 + 8.0 * math.cos(a), 12 + 8.0 * math.sin(a))
    tri = QPainterPath()
    tri.moveTo(tip.x() - 3.4, tip.y() - 1.3)
    tri.lineTo(tip.x() + 2.2, tip.y() - 2.9)
    tri.lineTo(tip.x() + 0.6, tip.y() + 2.7)
    tri.closeSubpath()
    f.addPath(tri)
    return s, f


def _moon():
    f = QPainterPath()
    outer = QPainterPath()
    outer.addEllipse(QPointF(12, 12), 8.6, 8.6)
    cut = QPainterPath()
    cut.addEllipse(QPointF(16.6, 8.2), 8.2, 8.2)
    f.addPath(outer.subtracted(cut))
    return None, f


def _sun():
    s = QPainterPath()
    for i in range(8):
        a = math.radians(i * 45)
        _line(s, 12 + 7.2 * math.cos(a), 12 + 7.2 * math.sin(a),
              12 + 9.9 * math.cos(a), 12 + 9.9 * math.sin(a))
    f = QPainterPath()
    f.addEllipse(QPointF(12, 12), 4.7, 4.7)
    return s, f


def _thermometer():
    s = QPainterPath()
    s.moveTo(9.4, 13.8)
    s.lineTo(9.4, 5.3)
    s.quadTo(9.4, 2.6, 12.0, 2.6)
    s.quadTo(14.6, 2.6, 14.6, 5.3)
    s.lineTo(14.6, 13.8)
    f = QPainterPath()
    f.addEllipse(QPointF(12, 17.4), 3.9, 3.9)
    return s, f


def _snowflake():
    s = QPainterPath()
    for i in range(3):
        a = math.radians(90 + i * 60)
        dx, dy = 9.4 * math.cos(a), 9.4 * math.sin(a)
        _line(s, 12 - dx, 12 - dy, 12 + dx, 12 + dy)
        for sgn in (1, -1):
            bx, by = 12 + sgn * dx * 0.62, 12 + sgn * dy * 0.62
            for da in (40, -40):
                b = a + math.radians(da) + (0 if sgn > 0 else math.pi)
                _line(s, bx, by, bx + 3.1 * math.cos(b), by + 3.1 * math.sin(b))
    return s, None


def _fan():
    """SF-ish: the heatsink fan. Three swept blades around a hub."""
    s = QPainterPath()
    for i in range(3):
        a = math.radians(i * 120 - 90)
        blade = QPainterPath()
        blade.moveTo(12 + 2.3 * math.cos(a + 1.35), 12 + 2.3 * math.sin(a + 1.35))
        blade.quadTo(12 + 10.6 * math.cos(a + 0.75), 12 + 10.6 * math.sin(a + 0.75),
                     12 + 9.3 * math.cos(a), 12 + 9.3 * math.sin(a))
        blade.quadTo(12 + 6.4 * math.cos(a - 0.55), 12 + 6.4 * math.sin(a - 0.55),
                     12 + 2.3 * math.cos(a - 1.35), 12 + 2.3 * math.sin(a - 1.35))
        s.addPath(blade)
    s.addEllipse(QPointF(12, 12), 2.3, 2.3)
    return s, None


def _bolt():
    f = QPainterPath()
    f.moveTo(13.6, 2.4)
    f.lineTo(5.9, 13.0)
    f.quadTo(5.2, 14.0, 6.4, 14.0)
    f.lineTo(10.8, 14.0)
    f.lineTo(9.6, 21.4)
    f.quadTo(9.4, 22.6, 10.3, 21.4)
    f.lineTo(18.1, 10.8)
    f.quadTo(18.8, 9.8, 17.6, 9.8)
    f.lineTo(13.2, 9.8)
    f.lineTo(14.4, 2.6)
    f.quadTo(14.6, 1.3, 13.6, 2.4)
    return None, f


def _chevron_right():
    s = QPainterPath()
    s.moveTo(9.2, 4.9)
    s.lineTo(16.0, 12.0)
    s.lineTo(9.2, 19.1)
    return s, None


def _chevron_down():
    s = QPainterPath()
    s.moveTo(4.9, 9.2)
    s.lineTo(12.0, 16.0)
    s.lineTo(19.1, 9.2)
    return s, None


def _link():
    s = QPainterPath()
    s.moveTo(10.0, 14.0)
    s.quadTo(12.0, 16.0, 14.0, 14.0)
    s.lineTo(17.6, 10.4)
    s.quadTo(20.4, 7.6, 17.6, 4.8)
    s.quadTo(14.8, 2.0, 12.0, 4.8)
    s.lineTo(10.6, 6.2)
    s.moveTo(14.0, 10.0)
    s.quadTo(12.0, 8.0, 10.0, 10.0)
    s.lineTo(6.4, 13.6)
    s.quadTo(3.6, 16.4, 6.4, 19.2)
    s.quadTo(9.2, 22.0, 12.0, 19.2)
    s.lineTo(13.4, 17.8)
    return s, None


def _waveform():
    """SF: waveform.path.ecg - the live trace."""
    s = QPainterPath()
    s.moveTo(2.4, 12.0)
    s.lineTo(7.0, 12.0)
    s.lineTo(9.3, 5.4)
    s.lineTo(12.6, 18.6)
    s.lineTo(15.0, 12.0)
    s.lineTo(21.6, 12.0)
    return s, None


def _doc_text():
    s = QPainterPath()
    s.moveTo(5.4, 4.6)
    s.quadTo(5.4, 2.8, 7.2, 2.8)
    s.lineTo(13.4, 2.8)
    s.lineTo(18.6, 8.0)
    s.lineTo(18.6, 19.4)
    s.quadTo(18.6, 21.2, 16.8, 21.2)
    s.lineTo(7.2, 21.2)
    s.quadTo(5.4, 21.2, 5.4, 19.4)
    s.closeSubpath()
    s.moveTo(13.4, 2.8)
    s.lineTo(13.4, 8.0)
    s.lineTo(18.6, 8.0)
    _line(s, 8.6, 12.6, 15.4, 12.6)
    _line(s, 8.6, 16.4, 13.4, 16.4)
    return s, None


def _exclam_triangle():
    s = QPainterPath()
    s.moveTo(12.0, 3.4)
    s.lineTo(21.2, 19.4)
    s.quadTo(22.2, 21.0, 20.4, 21.0)
    s.lineTo(3.6, 21.0)
    s.quadTo(1.8, 21.0, 2.8, 19.4)
    s.closeSubpath()
    _line(s, 12, 9.4, 12, 15.0)
    f = QPainterPath()
    f.addEllipse(QPointF(12, 18.1), 1.05, 1.05)
    return s, f


def _info():
    s = QPainterPath()
    s.addEllipse(QPointF(12, 12), 9.0, 9.0)
    _line(s, 12, 11.2, 12, 17.0)
    f = QPainterPath()
    f.addEllipse(QPointF(12, 7.5), 1.15, 1.15)
    return s, f


GLYPHS = {
    'gauge': _gauge, 'list': _list_bullet, 'archive': _archivebox,
    'sliders': _sliders, 'gear': _gear, 'play': _play, 'stop': _stop,
    'pause': _pause, 'xmark': _xmark, 'check': _checkmark, 'plus': _plus,
    'minus': _minus, 'trash': _trash, 'export': _square_arrow_down,
    'share': _square_arrow_up, 'folder': _folder, 'refresh': _arrow_clockwise,
    'moon': _moon, 'sun': _sun, 'thermometer': _thermometer,
    'snowflake': _snowflake, 'fan': _fan, 'bolt': _bolt,
    'chevron': _chevron_right, 'chevron_down': _chevron_down, 'link': _link,
    'waveform': _waveform, 'doc': _doc_text, 'warning': _exclam_triangle,
    'info': _info,
}


def pixmap(name: str, size: int, color: str, weight: float = 1.9,
           dpr: float = 2.0) -> QPixmap:
    """One glyph, painted at `size` logical px in `color`.

    `weight` is the stroke width on the 24-grid: 1.6 is SF's "light", 1.9
    "regular", 2.4 "semibold". `dpr` renders above device resolution so the
    same pixmap stays sharp if Qt moves the window to a denser screen.
    """
    key = (name, size, color, weight, dpr)
    hit = _CACHE.get(key)
    if hit is not None:
        return hit

    px = QPixmap(int(size * dpr), int(size * dpr))
    px.setDevicePixelRatio(dpr)
    px.fill(Qt.GlobalColor.transparent)

    stroke, fill = GLYPHS.get(name, _info)()
    q = QPainter(px)
    q.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    # QPainter on a pixmap with a device-pixel ratio already works in LOGICAL
    # coordinates, so the grid maps to `size`, not to size*dpr. Scaling by the
    # device size here would draw the glyph at 2x and clip it to a corner.
    k = size / G
    q.setTransform(QTransform().scale(k, k))
    col = QColor(color)
    if fill is not None:
        q.setPen(Qt.PenStyle.NoPen)
        q.setBrush(col)
        q.drawPath(fill)
    if stroke is not None:
        pen = QPen(col, weight)
        pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
        q.setPen(pen)
        q.setBrush(Qt.BrushStyle.NoBrush)
        q.drawPath(stroke)
    q.end()

    _CACHE[key] = px
    return px


def icon(name: str, size: int, color: str, weight: float = 1.9) -> QIcon:
    return QIcon(pixmap(name, size, color, weight))


def clear_cache():
    """Called when the appearance flips, so glyphs are repainted in the new tint."""
    _CACHE.clear()
